/* ============================================================
 * 【数据层】js/data.js
 * ------------------------------------------------------------
 * 你只需要改这个文件，就能替换成自己的商品和教程。
 *
 * 结构说明：
 *   SITE_CONFIG -> 站点名称、Logo、搜索框提示文字
 *   CATEGORIES  -> 主类目与子类目（children 就是子类目）
 *   PRODUCTS    -> 主类公共信息（名称、图标、颜色、标签、关键词）
 *   SUBCATEGORY_CONTENT -> 每个子类目的独立教程正文
 *
 * 注释标签：
 *   [配置] 网站配置    [分类] 目录结构
 *   [主类信息] 主类公共字段    [子目录内容] 可单独修改的教程内容
 *
 * 子类目维护规则：
 *   1. 在对应主类的 children 数组中增删对象，即可新增或删除子类目。
 *   2. 删除整个主类对象即可删除该主类，对应教程不会残留在“全部”中。
 *   3. PRODUCTS 只提供主类公共信息；完整教程正文放在 SUBCATEGORY_CONTENT 中。
 *   4. id 建议使用唯一英文；label 是页面显示名称；icon 可选。
 *   5. 如某个子类直接填写 desc、keywords、steps，则该子类优先使用自身内容。
 *
 * body 数组支持的内容块类型：
 *   { type:"p",     text:"段落，支持 **加粗** 和 `代码`" }
 *   { type:"list",  items:["无序列表项"] }
 *   { type:"olist", items:["有序列表项"] }
 *   { type:"tip",   text:"提示框" }
 *   { type:"warn",  text:"警告框" }
 *   { type:"code",  lang:"bash", text:"代码内容" }
 *   { type:"img",   src:"图片地址", alt:"替代文字", caption:"图注" }
 *   { type:"video", src:"视频地址", caption:"视频说明" }
 *   { type:"table", head:["列1","列2"], rows:[["值1","值2"]] }
 * ============================================================ */

/* ---------- 站点基础配置 ---------- */
const SITE_CONFIG = {
  brand: "湖北视感闪租相机使用教程",
  logo: "",
  logoImage: "images/视感闪租 LOGO-02.jpg",
  searchPlaceholder: "搜索商品或教程关键词…",
  // [配置] logoImage 填写图片路径后优先显示图片；留空时显示 logo 表情
};

/* ---------- 首页基础配置 ---------- */
const HOME_CONFIG = {
  brand: "湖北视感闪租相机租赁",
  title: "各类相机使用简易教程",
  subtitle: "选择下方目录，快速查看对应设备的使用教程",
  services: [
    {
      title: "在线租赁客服",
      hours: "早9:20—晚11:30",
      qr: "images/客服售后二维码.jpg",
      qrText: "扫码联系租赁客服"
    },
    {
      title: "售后客服",
      hours: "早9:00—晚11:30",
      qr: "images/客服售后二维码.jpg",
      qrText: "扫码联系售后客服"
    }
  ]
};

/* ---------- 分类列表（children 为子类目，可自由增删，复制其中一行进行复制粘贴后修改文字即可） ---------- */
const CATEGORIES = [
  { value: "all", label: "全部" },
  {
    value: "手持云台相机",
    label: "手持云台相机",
    homeDesc: "稳定跟拍，适合 Vlog 和日常记录",
    icon: "🎥",
    iconImage: "images/category-icons/gimbal-camera.svg",
    children: [
      { id: "gimbal-phone",  value: "大疆pocket3标准版",   label: "大疆pocket3标准版",   icon: "📱", iconImage: "images/category-icons/children/pocket3-standard.svg" },
      { id: "gimbal-one",  value: "大疆pocket3长续航版",   label: "大疆pocket3长续航版",   icon: "📱", iconImage: "images/category-icons/children/pocket3-long-battery.svg" },
      { id: "gimbal-two",  value: "大疆pocket3全能版",   label: "大疆pocket3全能版",   icon: "📱", iconImage: "images/category-icons/children/pocket3-creator.svg" },
      { id: "gimbal-pocket4pro-standard", value: "大疆Pocket 4 Pro标准套装", label: "大疆Pocket 4 Pro标准套装", icon: "📱", iconImage: "images/category-icons/children/pocket4pro-standard.svg" },
      { id: "gimbal-pocket4pro-combo", value: "大疆Pocket 4 Pro全能套装", label: "大疆Pocket 4 Pro全能套装", icon: "📱", iconImage: "images/category-icons/children/pocket4pro-combo.svg" },
    ]
  },
  {
    value: "运动相机",
    label: "运动相机",
    homeDesc: "户外运动，防水防抖记录精彩瞬间",
    icon: "🎿",
    iconImage: "images/category-icons/action-camera.svg",
    children: [
      { id: "action-standard", value: "影石ACEPro2",       label: "影石ACEpro2",       icon: "🎿", iconImage: "images/category-icons/children/acepro2-standard.svg" },
      { id: "action-street", value: "影石ACEPro2街拍套装",       label: "影石ACEpro2街拍套装",       icon: "🎿", iconImage: "images/category-icons/children/acepro2-street.svg" },
      { id: "action-neck", value: "影石ACEPro2挂脖套装",       label: "影石ACEpro2挂脖套装",       icon: "🎿", iconImage: "images/category-icons/children/acepro2-neck.svg" },
      { id: "action-vlog", value: "影石ACEPro2手持vlog套装",       label: "影石ACEpro2手持vlog套装",       icon: "🎿", iconImage: "images/category-icons/children/acepro2-vlog.svg" },

    ]
  },
  {
    value: "全景相机",
    label: "全景相机",
    homeDesc: "360°全景记录，适合旅行、运动和创意拍摄",
    icon: "🌐",
    iconImage: "images/category-icons/panorama-camera.svg",
    children: [
      { id: "insta360-x6-standard", value: "影石Insta360 X6标准版", label: "影石Insta360 X6标准版", icon: "🌐", iconImage: "images/category-icons/children/x6-standard.svg" },
      { id: "insta360-x6-allround", value: "影石Insta360 X6全能版", label: "影石Insta360 X6全能版", icon: "🎒", iconImage: "images/category-icons/children/x6-allround.svg" },
      { id: "insta360-x6-travel", value: "影石Insta360 X6旅拍套装", label: "影石Insta360 X6旅拍套装", icon: "✈️", iconImage: "images/category-icons/children/x6-travel.svg" }
    ]
  },
  {
    value: "微单相机",
    label: "微单相机",
    homeDesc: "高清画质，适合人像、旅行和专业拍摄",
    icon: "📷",
    iconImage: "images/category-icons/mirrorless-camera.svg",
    children: [
      { id: "mirrorless-entry", value: "佳能微单+18-45mm入门套镜头", label: "佳能微单+18-45mm入门套镜头", icon: "🎬", iconImage: "images/category-icons/children/mirrorless-18-45.svg" },
      { id: "mirrorless-plus",  value: "佳能微单+18-150mm风光变焦镜头", label: "佳能微单+18-150mm风光变焦镜头", icon: "📷", iconImage: "images/category-icons/children/mirrorless-18-150.svg" },
      { id: "mirrorless-pro",   value: "佳能微单+F1.8人像大光圈镜头", label: "佳能微单+F1.8人像大光圈镜头", icon: "🎞️", iconImage: "images/category-icons/children/mirrorless-f18.svg" },
      { id: "mirrorless-one",   value: "佳能微单+超远摄100-400mm", label: "佳能微单+超远摄100-400mm", icon: "🔍", iconImage: "images/category-icons/children/mirrorless-100-400.svg" }
    ]
  },
  {
    value: "卡片相机",
    label: "卡片相机",
    homeDesc: "轻巧便携，旅行和日常随手拍",
    icon: "📸",
    iconImage: "images/category-icons/compact-camera.svg",
    children: [
      { id: "compact-entry", value: "佳能卡片相机标准版", label: "佳能卡片相机标准版", icon: "📸", iconImage: "images/category-icons/children/compact-standard.svg" },
      { id: "compact-vlog",  value: "佳能无线蓝牙自拍杆版", label: "佳能无线蓝牙自拍杆版", icon: "🎥", iconImage: "images/category-icons/children/compact-selfie.svg" },
    ]
  },
  {
    value: "CCD相机",
    label: "CCD相机",
    homeDesc: "复古CCD画质，适合日常、旅行和氛围感照片",
    icon: "📻",
    iconImage: "images/category-icons/ccd-camera.svg",
    children: [
      { id: "canon-ixus-210", value: "佳能IXU210复古CCD相机", label: "佳能IXU210复古CCD相机", icon: "📸", iconImage: "images/category-icons/children/ccd-210.svg" },
      { id: "canon-ixus-130", value: "佳能IXU130复古CCD相机", label: "佳能IXU130复古CCD相机", icon: "📷", iconImage: "images/category-icons/children/ccd-130.svg" }
    ]
  },
  {
    value: "落地三脚架",
    label: "落地三脚架",
    homeDesc: "稳定支撑，直播和拍摄更省心",
    icon: "🔭",
    iconImage: "images/category-icons/tripod.svg",
    children: [
      { id: "tripod-live",  value: "富宝图FY-830-MH-4A液压云台标准版",   label: "富宝图FY-830-MH-4A液压云台标准版",   icon: "📱", iconImage: "images/category-icons/children/tripod-hydraulic.svg" },
      { id: "tripod-cam",   value: "富宝图FY-830-MH-4A所含配件可自选赠送使用",   label: "富宝图FY-830-MH-4A所含配件可自选赠送使用",   icon: "📷", iconImage: "images/category-icons/children/tripod-accessories.svg" },
    ]
  },
  {
    value: "内存卡数据找回",
    label: "内存卡数据找回",
    homeDesc: "素材误删，尝试找回重要照片和视频",
    icon: "💾",
    iconImage: "images/category-icons/memory-recovery.svg",
    children: [
      { id: "recovery-sd",   value: "SD 卡",       label: "SD 卡",       icon: "💾", iconImage: "images/category-icons/children/recovery-sd.svg" },
      { id: "recovery-tf",   value: "TF 卡",       label: "TF 卡",       icon: "📱", iconImage: "images/category-icons/children/recovery-tf.svg" },
    ]
  }
];

/* ---------- 主类公共信息模板 ----------
 * PRODUCTS 只保留主类名称、图标、颜色和搜索关键词等公共信息。
 * 每个子目录的完整教程正文统一放在下方 SUBCATEGORY_CONTENT 中，便于单独修改。
 */
const PRODUCTS = [
  {
    id: "sp-x1",
    name: "手持云台相机",
    icon: "🎥",
    category: "手持云台相机",
    tag: "热门",
    color: "#6366f1",
    desc: "手持云台系列简易说明教程",
    keywords: "大疆 Pocket 3 手持云台 相机 开机 拍照 录像 续航 内存卡 导出"
  },
  {
    id: "hp-pro",
    name: "运动相机",
    icon: "🎿",
    category: "运动相机",
    tag: "",
    color: "#0ea5e9",
    desc: "运动相机系列简易使用说明教程",
    keywords: "影石 Ace Pro 2 运动相机 防水 防抖 拍照 录像 内存卡 导出"
  },
  {
    id: "mirrorless-template",
    name: "微单相机",
    icon: "🎬",
    category: "微单相机",
    tag: "专业画质",
    color: "#10b981",
    desc: "微单相机与镜头组合简易使用说明",
    keywords: "佳能 微单 镜头 拍照 录像 光圈 对焦 内存卡 导出"
  },
  {
    id: "compact-template",
    name: "卡片相机",
    icon: "📸",
    category: "卡片相机",
    tag: "轻便",
    color: "#d97706",
    desc: "卡片相机简易使用说明教程",
    keywords: "佳能 G7 X Mark III 卡片相机 拍照 录像 自拍杆 导出"
  },
  {
    id: "tripod-template",
    name: "落地三脚架",
    icon: "🔭",
    category: "落地三脚架",
    tag: "",
    color: "#f97316",
    desc: "富图宝 FY-830 + MH-4A 落地三脚架使用说明",
    keywords: "富图宝 FY-830 MH-4A 三脚架 液压云台 手机夹 配件"
  },
  {
    id: "recovery-template",
    name: "内存卡数据找回",
    icon: "💾",
    category: "内存卡数据找回",
    tag: "",
    color: "#dc2626",
    desc: "误删照片或视频后的数据找回参考说明",
    keywords: "内存卡 数据恢复 照片 视频 SD卡 TF卡 误删 格式化"
  }
]

/* ---------- 每个子类目的独立教程内容（可单独修改） ----------
 * 点击子类后，右侧会读取这里相同 id 的内容。
 * 可单独修改每个子类的 desc、keywords、steps，不会影响其他子类。
 */
/* ---------- 手持云台子目录第一列 ----------
*/
const SUBCATEGORY_CONTENT = {
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  "gimbal-phone": {
    "desc": "手持云台系列简易说明教程",
    "keywords": "大疆 Pocket 3 手持云台 相机 开机 拍照 录像 续航 内存卡 导出",
    "steps": [
      {
        "title": "开箱与配件确认",
        "icon": "📦",
        "body": [
          {
            "type": "p",
            "text": "打开包装后，请先核对以下配件是否齐全。如缺少相机相关配件或者无法使用的情况请及时联系售后客服，以防耽误您的使用时间。"
          },
          {
            "type": "list",
            "items": [
              "因选购版本不同，相机配件也不同",
              "相机主机x1",
              "官方保护壳x1",
              "收纳包x1",
              "128G内存卡x1",
              "手绳x1",
              "USB读卡器x1",
              "长续航版在标准版基础上增加：",
              "原厂续航手柄x1",
              "全能套装在标准版基础上增加：",
              " 原厂续航手柄x1",
              "迷你三脚架x1",
              "DJI Mic2发射器",
              "Osmo pocket3增广镜",
              "DJI Mic2防风毛套",
              "DJI Mic2磁吸背夹"
            ]
          },
          {
            "type": "tip",
            "text": "因为手持云台较为脆弱，请您在使用过程中爱护相机，请勿磕碰、严重划痕、丢失相机等 如有货损或丢失需要进行赔付。"
          }
        ]
      },
      {
        "title": "相机首次开机使用说明",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机收到后如无法开机可将相机连接充电线进行充电"
          },
          {
            "type": "olist",
            "items": [
              "相机正面（有显示屏的页面）轻推屏幕向左旋转",
              "轻推后显示屏会点亮云台会开启，开启后请不要使劲按压屏幕和掰动云台转轴",
              "相机正面有摇杆，摇杆往上画面也会同步往上，同理摇杆往下画面也会往下",
              "如需放大画面，可在相机开机后点击屏幕右侧的放大和方向按钮，再使用摇杆向上放大、向下缩小。",
              "摇杆右侧是录制按钮。点击开始录制，再次点击结束录制。"
            ]
          },
          {
            "type": "video",
            "className": "gimbal-start-video",
            "src": "images/使用说明教程.mp4",
            "caption": "相机使用说明教程"
          },
          {
            "type": "warn",
            "text": "如您在使用过程中相机使用出现任何意外情况请第一时间联系客服售后进处理。"
          }
        ]
      },
      {
        "title": "相机可切换的模式",
        "icon": "🎛️",
        "body": [
          {
            "type": "p",
            "text": "相机开机后点击屏幕左下角可手动更改为直接需要的拍照/视频模式等其他等其他模式 具体如下："
          },
          {
            "type": "table",
            "head": [
              "模式",
              "可直接切换的模式"
            ],
            "rows": [
              [
                "普通视频录制",
                "1080P——4K 60帧任意调节录制画质大小（画质越高耗电越高，占用存储也越高，设备也会发热）"
              ],
              [
                "普通拍照",
                "普通拍照，定格画面按下快门即可随拍"
              ],
              [
                "全景模式",
                "切换全景模式最高可支持180°拍摄照片"
              ],
              [
                "低光视频",
                "专为暗光环境设计，通过算法降低画面噪点、提升亮度（此模式仅在 4K 30即一下帧率"
              ],
              [
                "低光视频",
                "专为暗光环境设计，通过算法降低画面噪点、提升亮度（此模式仅在 4K 30即一下帧率才可启用"
              ],
              [
                "慢动作",
                "用于捕捉快速运动的瞬间，如运动、舞蹈、宠物奔跑等，最高拍摄支持4K 120帧率"
              ],
              [
                "延时摄影",
                "将长时间过程压缩为短视频，适合拍摄云卷云舒、日出日落、城市车流等"
              ],
              [
                "智能跟随",
                "双击屏幕中的目标即可开启，无论您如何握持或运镜，被追踪的主体（如人物）都会始终保持在画面中心，非常适合单人 Vlog 或拍摄运动对象。"
              ],
              [
                "旋转运镜",
                "支持一键完成 90° 或 180° 的平滑旋转拍摄，能创造出独特的镜头语言，增加画面动感。"
              ],
              [
                "竖拍模式",
                "通过旋转屏幕或锁定竖屏，可直接拍摄适合手机社交平台分享的竖版视频。注意：竖拍模式下的最高分辨率为 3K（由横向画面裁剪而来）"
              ]
            ]
          }
        ]
      },
      {
        "title": "相机滤镜美颜调整",
        "icon": "✨",
        "body": [
          {
            "type": "p",
            "text": "此列是相机如何设置美颜和滤镜的调整设置（请根据自己的需要调整，滤镜并不适用于所有场景）"
          },
          {
            "type": "olist",
            "items": [
              "将相机开机后，使用手指从屏幕右侧向左侧轻微滑动屏幕即可调出滤镜参数（美颜开关页面）",
              "如您需要开启美颜即可在调出的页面点击美颜开关即可",
              "需要调整滤镜参数，点击滑动后调出的页面 右上角有个 Pro 这个按钮选项 点击后即可进入滤镜调整页面",
              "例如：需要调整曝光：点击曝光选项，弹出的页面有可调整的选项，按需要调整完成后点击确定就可以啦"
            ]
          },
          {
            "type": "img",
            "src": "images/滤镜参数推荐.jpg",
            "alt": "相机滤镜参数推荐调整示意图",
            "caption": "滤镜参数推荐调整参考（可根据实际拍摄场景自行微调）"
          },
          {
            "type": "tip",
            "text": "如有不清楚的地方请联系客服售后"
          }
        ]
      },
      {
        "title": "相机收纳说明",
        "icon": "🎒",
        "body": [
          {
            "type": "p",
            "text": "相机收到后如无法开机可将相机连接充电线进行充电"
          },
          {
            "type": "olist",
            "items": [
              "相机完全关机（云台转轴也自动收纳完成）",
              "将相机正面朝下（含显示屏的方向朝下）",
              "拿起官方保护壳，将大疆pocket3对准保护壳进行收纳（云台转轴凸起对准保护壳缺口后轻轻按压机身即可完成收纳）",
              "请勿随意收纳（正面朝上、侧放相机、反方向放置相机等）"
            ]
          },
          {
            "type": "video",
            "src": "images/收纳说明.mp4",
            "caption": "相机正确收纳说明"
          },
          {
            "type": "tip",
            "text": "如您不清楚如何进行收纳可联系售后客服进行咨询"
          }
        ]
      },
      {
        "title": "常见问题排查",
        "icon": "🛠️",
        "body": [
          {
            "type": "p",
            "text": "如您开拍摄过程中出现异常可尝试解决："
          },
          {
            "type": "olist",
            "items": [
              "11相机无法关机可尝试进行强制关机：长按相机拍摄按钮至相机屏幕黑屏和云台回收完成  强制关机后稍等一会可尝试重新开机",
              "如相机无法进行链接手机，可按此操作：相机开机——屏幕顶部向下滑动——点击齿轮图标（设置）——向下滑动菜单栏找到（无线连接）——点击Wi-Fi频段更改为2.4GHz 修改好后相机重启手机app重启进行连接。",
              "拍摄的视频手机无法保存：下载DJI Mimo应用程序打开后，请把app所需的权限全部允许，如拒绝的情况可能会出现无法保存图像的情况。",
              "如还有其他状况问题请及时联系客服售后进行处理解决。"
            ]
          },
          {
            "type": "code",
            "lang": "bash",
            "text": "# 查看设备 SN 码（位于机身底部标签或相机设置内查看）\nSN: 5WXXXXXXXXXXXXX"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[DJI Mimo](https://www.dji.com/cn/downloads/djiapp/dji-mimo)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 DJI Mimo，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },

/* ---------- 手持云台相机目录第二列（需增加复制以下整体进行修改即可） ----------
*/

  /* 长续航版独立教程内容，可单独修改 */
  // 子目录内容：手持云台相机 · 大疆pocket3长续航版
  "gimbal-one": {
    "desc": "手持云台系列简易说明教程",
    "keywords": "大疆 Pocket 3 手持云台 相机 开机 拍照 录像 续航 内存卡 导出",
    "steps": [
      {
        "title": "开箱与配件确认",
        "icon": "📦",
        "body": [
          {
            "type": "p",
            "text": "打开包装后，请先核对以下配件是否齐全。如缺少相机相关配件或者无法使用的情况请及时联系售后客服，以防耽误您的使用时间。"
          },
          {
            "type": "list",
            "items": [
              "此页面为大疆pocket3手持云台长续航版（只是配件不同，操作一致）",
              "相机主机x1",
              "官方保护壳x1",
              "收纳包x1",
              "128G内存卡x1",
              "手绳x1",
              "USB读卡器x1",
              "原厂续航手柄x1"
            ]
          },
          {
            "type": "tip",
            "text": "因为手持云台较为脆弱，请您在使用过程中爱护相机，请勿磕碰、严重划痕、丢失相机等 如有货损或丢失需要进行赔付。"
          }
        ]
      },
      {
        "title": "相机首次开机使用说明",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机收到后如无法开机可将相机连接充电线进行充电"
          },
          {
            "type": "olist",
            "items": [
              "相机正面（有显示屏的页面）轻推屏幕向左旋转",
              "轻推后显示屏会点亮云台会开启，开启后请不要使劲按压屏幕和掰动云台转轴",
              "相机正面有摇杆，摇杆往上画面也会同步往上，同理摇杆往下画面也会往下",
              "如需放大画面，可在相机开机后点击屏幕右侧的放大和方向按钮，再使用摇杆向上放大、向下缩小。",
              "摇杆右侧是录制按钮。点击开始录制，再次点击结束录制。"
            ]
          },
          {
            "type": "video",
            "className": "gimbal-start-video",
            "src": "images/使用说明教程.mp4",
            "caption": "相机使用说明教程"
          },
          {
            "type": "warn",
            "text": "如您在使用过程中相机使用出现任何意外情况请第一时间联系客服售后进处理。"
          }
        ]
      },
      {
        "title": "相机可切换的模式",
        "icon": "🎛️",
        "body": [
          {
            "type": "p",
            "text": "相机开机后点击屏幕左下角可手动更改为直接需要的拍照/视频模式等其他等其他模式 具体如下："
          },
          {
            "type": "table",
            "head": [
              "模式",
              "可直接切换的模式"
            ],
            "rows": [
              [
                "普通视频录制",
                "1080P——4K 60帧任意调节录制画质大小（画质越高耗电越高，占用存储也越高，设备也会发热）"
              ],
              [
                "普通拍照",
                "普通拍照，定格画面按下快门即可随拍"
              ],
              [
                "全景模式",
                "切换全景模式最高可支持180°拍摄照片"
              ],
              [
                "低光视频",
                "专为暗光环境设计，通过算法降低画面噪点、提升亮度（此模式仅在 4K 30即一下帧率"
              ],
              [
                "低光视频",
                "专为暗光环境设计，通过算法降低画面噪点、提升亮度（此模式仅在 4K 30即一下帧率才可启用"
              ],
              [
                "慢动作",
                "用于捕捉快速运动的瞬间，如运动、舞蹈、宠物奔跑等，最高拍摄支持4K 120帧率"
              ],
              [
                "延时摄影",
                "将长时间过程压缩为短视频，适合拍摄云卷云舒、日出日落、城市车流等"
              ],
              [
                "智能跟随",
                "双击屏幕中的目标即可开启，无论您如何握持或运镜，被追踪的主体（如人物）都会始终保持在画面中心，非常适合单人 Vlog 或拍摄运动对象。"
              ],
              [
                "旋转运镜",
                "支持一键完成 90° 或 180° 的平滑旋转拍摄，能创造出独特的镜头语言，增加画面动感。"
              ],
              [
                "竖拍模式",
                "通过旋转屏幕或锁定竖屏，可直接拍摄适合手机社交平台分享的竖版视频。注意：竖拍模式下的最高分辨率为 3K（由横向画面裁剪而来）"
              ]
            ]
          }
        ]
      },
      {
        "title": "相机滤镜美颜调整",
        "icon": "✨",
        "body": [
          {
            "type": "p",
            "text": "此列是相机如何设置美颜和滤镜的调整设置（请根据自己的需要调整，滤镜并不适用于所有场景）"
          },
          {
            "type": "olist",
            "items": [
              "将相机开机后，使用手指从屏幕右侧向左侧轻微滑动屏幕即可调出滤镜参数（美颜开关页面）",
              "如您需要开启美颜即可在调出的页面点击美颜开关即可",
              "需要调整滤镜参数，点击滑动后调出的页面 右上角有个 Pro 这个按钮选项 点击后即可进入滤镜调整页面",
              "例如：需要调整曝光：点击曝光选项，弹出的页面有可调整的选项，按需要调整完成后点击确定就可以啦"
            ]
          },
          {
            "type": "img",
            "src": "images/滤镜参数推荐.jpg",
            "alt": "相机滤镜参数推荐调整示意图",
            "caption": "滤镜参数推荐调整参考（可根据实际拍摄场景自行微调）"
          },
          {
            "type": "tip",
            "text": "如有不清楚的地方请联系客服售后"
          }
        ]
      },
      {
        "title": "相机收纳说明",
        "icon": "🎒",
        "body": [
          {
            "type": "p",
            "text": "相机收到后如无法开机可将相机连接充电线进行充电"
          },
          {
            "type": "olist",
            "items": [
              "相机完全关机（云台转轴也自动收纳完成）",
              "将相机正面朝下（含显示屏的方向朝下）",
              "拿起官方保护壳，将大疆pocket3对准保护壳进行收纳（云台转轴凸起对准保护壳缺口后轻轻按压机身即可完成收纳）",
              "请勿随意收纳（正面朝上、侧放相机、反方向放置相机等）"
            ]
          },
          {
            "type": "video",
            "src": "images/收纳说明.mp4",
            "caption": "相机正确收纳说明"
          },
          {
            "type": "tip",
            "text": "如您不清楚如何进行收纳可联系售后客服进行咨询"
          }
        ]
      },
      {
        "title": "常见问题排查",
        "icon": "🛠️",
        "body": [
          {
            "type": "p",
            "text": "如您开拍摄过程中出现异常可尝试解决："
          },
          {
            "type": "olist",
            "items": [
              "11相机无法关机可尝试进行强制关机：长按相机拍摄按钮至相机屏幕黑屏和云台回收完成  强制关机后稍等一会可尝试重新开机",
              "如相机无法进行链接手机，可按此操作：相机开机——屏幕顶部向下滑动——点击齿轮图标（设置）——向下滑动菜单栏找到（无线连接）——点击Wi-Fi频段更改为2.4GHz 修改好后相机重启手机app重启进行连接。",
              "拍摄的视频手机无法保存：下载DJI Mimo应用程序打开后，请把app所需的权限全部允许，如拒绝的情况可能会出现无法保存图像的情况。",
              "如还有其他状况问题请及时联系客服售后进行处理解决。"
            ]
          },
          {
            "type": "code",
            "lang": "bash",
            "text": "# 查看设备 SN 码（位于机身底部标签或相机设置内查看）\nSN: 5WXXXXXXXXXXXXX"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[DJI Mimo](https://www.dji.com/cn/downloads/djiapp/dji-mimo)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 DJI Mimo，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },

/* ---------- 手持云台相机目录第三列（需增加复制以下整体进行修改即可） ----------
*/

  /* 全能版独立教程内容，可单独修改 */
  // 子目录内容：手持云台相机 · 大疆pocket3全能版
  "gimbal-two": {
    "desc": "手持云台系列简易说明教程",
    "keywords": "大疆 Pocket 3 手持云台 相机 开机 拍照 录像 续航 内存卡 导出",
    "steps": [
      {
        "title": "开箱与配件确认",
        "icon": "📦",
        "body": [
          {
            "type": "p",
            "text": "打开包装后，请先核对以下配件是否齐全。如缺少相机相关配件或者无法使用的情况请及时联系售后客服，以防耽误您的使用时间。"
          },
          {
            "type": "list",
            "items": [
              "此链接为大疆pocket3全能版（只是配件不同，相机整体操作一致）",
              "相机主机x1",
              "官方保护壳x1",
              "收纳包x1",
              "128G内存卡x1",
              "手绳x1",
              "USB读卡器x1",
              "长续航版在标准版基础上增加：",
              "原厂续航手柄x1",
              "全能套装在标准版基础上增加：",
              " 原厂续航手柄x1",
              "迷你三脚架x1",
              "DJI Mic2发射器",
              "Osmo pocket3增广镜",
              "DJI Mic2防风毛套",
              "DJI Mic2磁吸背夹"
            ]
          },
          {
            "type": "tip",
            "text": "因为手持云台较为脆弱，请您在使用过程中爱护相机，请勿磕碰、严重划痕、丢失相机等 如有货损或丢失需要进行赔付。"
          }
        ]
      },
      {
        "title": "相机首次开机使用说明",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机收到后如无法开机可将相机连接充电线进行充电"
          },
          {
            "type": "olist",
            "items": [
              "相机正面（有显示屏的页面）轻推屏幕向左旋转",
              "轻推后显示屏会点亮云台会开启，开启后请不要使劲按压屏幕和掰动云台转轴",
              "相机正面有摇杆，摇杆往上画面也会同步往上，同理摇杆往下画面也会往下",
              "如需放大画面，可在相机开机后点击屏幕右侧的放大和方向按钮，再使用摇杆向上放大、向下缩小。",
              "摇杆右侧是录制按钮。点击开始录制，再次点击结束录制。"
            ]
          },
          {
            "type": "video",
            "className": "gimbal-start-video",
            "src": "images/使用说明教程.mp4",
            "caption": "相机使用说明教程"
          },
          {
            "type": "warn",
            "text": "如您在使用过程中相机使用出现任何意外情况请第一时间联系客服售后进处理。"
          }
        ]
      },
      {
        "title": "相机可切换的模式",
        "icon": "🎛️",
        "body": [
          {
            "type": "p",
            "text": "相机开机后点击屏幕左下角可手动更改为直接需要的拍照/视频模式等其他等其他模式 具体如下："
          },
          {
            "type": "table",
            "head": [
              "模式",
              "可直接切换的模式"
            ],
            "rows": [
              [
                "普通视频录制",
                "1080P——4K 60帧任意调节录制画质大小（画质越高耗电越高，占用存储也越高，设备也会发热）"
              ],
              [
                "普通拍照",
                "普通拍照，定格画面按下快门即可随拍"
              ],
              [
                "全景模式",
                "切换全景模式最高可支持180°拍摄照片"
              ],
              [
                "低光视频",
                "专为暗光环境设计，通过算法降低画面噪点、提升亮度（此模式仅在 4K 30即一下帧率"
              ],
              [
                "低光视频",
                "专为暗光环境设计，通过算法降低画面噪点、提升亮度（此模式仅在 4K 30即一下帧率才可启用"
              ],
              [
                "慢动作",
                "用于捕捉快速运动的瞬间，如运动、舞蹈、宠物奔跑等，最高拍摄支持4K 120帧率"
              ],
              [
                "延时摄影",
                "将长时间过程压缩为短视频，适合拍摄云卷云舒、日出日落、城市车流等"
              ],
              [
                "智能跟随",
                "双击屏幕中的目标即可开启，无论您如何握持或运镜，被追踪的主体（如人物）都会始终保持在画面中心，非常适合单人 Vlog 或拍摄运动对象。"
              ],
              [
                "旋转运镜",
                "支持一键完成 90° 或 180° 的平滑旋转拍摄，能创造出独特的镜头语言，增加画面动感。"
              ],
              [
                "竖拍模式",
                "通过旋转屏幕或锁定竖屏，可直接拍摄适合手机社交平台分享的竖版视频。注意：竖拍模式下的最高分辨率为 3K（由横向画面裁剪而来）"
              ]
            ]
          }
        ]
      },
      {
        "title": "相机滤镜美颜调整",
        "icon": "✨",
        "body": [
          {
            "type": "p",
            "text": "此列是相机如何设置美颜和滤镜的调整设置（请根据自己的需要调整，滤镜并不适用于所有场景）"
          },
          {
            "type": "olist",
            "items": [
              "将相机开机后，使用手指从屏幕右侧向左侧轻微滑动屏幕即可调出滤镜参数（美颜开关页面）",
              "如您需要开启美颜即可在调出的页面点击美颜开关即可",
              "需要调整滤镜参数，点击滑动后调出的页面 右上角有个 Pro 这个按钮选项 点击后即可进入滤镜调整页面",
              "例如：需要调整曝光：点击曝光选项，弹出的页面有可调整的选项，按需要调整完成后点击确定就可以啦"
            ]
          },
          {
            "type": "img",
            "src": "images/滤镜参数推荐.jpg",
            "alt": "相机滤镜参数推荐调整示意图",
            "caption": "滤镜参数推荐调整参考（可根据实际拍摄场景自行微调）"
          },
          {
            "type": "tip",
            "text": "如有不清楚的地方请联系客服售后"
          }
        ]
      },
      {
        "title": "相机收纳说明",
        "icon": "🎒",
        "body": [
          {
            "type": "p",
            "text": "相机收到后如无法开机可将相机连接充电线进行充电"
          },
          {
            "type": "olist",
            "items": [
              "相机完全关机（云台转轴也自动收纳完成）",
              "将相机正面朝下（含显示屏的方向朝下）",
              "拿起官方保护壳，将大疆pocket3对准保护壳进行收纳（云台转轴凸起对准保护壳缺口后轻轻按压机身即可完成收纳）",
              "请勿随意收纳（正面朝上、侧放相机、反方向放置相机等）"
            ]
          },
          {
            "type": "video",
            "src": "images/收纳说明.mp4",
            "caption": "相机正确收纳说明"
          },
          {
            "type": "tip",
            "text": "如您不清楚如何进行收纳可联系售后客服进行咨询"
          }
        ]
      },
      {
        "title": "常见问题排查",
        "icon": "🛠️",
        "body": [
          {
            "type": "p",
            "text": "如您开拍摄过程中出现异常可尝试解决："
          },
          {
            "type": "olist",
            "items": [
              "11相机无法关机可尝试进行强制关机：长按相机拍摄按钮至相机屏幕黑屏和云台回收完成  强制关机后稍等一会可尝试重新开机",
              "如相机无法进行链接手机，可按此操作：相机开机——屏幕顶部向下滑动——点击齿轮图标（设置）——向下滑动菜单栏找到（无线连接）——点击Wi-Fi频段更改为2.4GHz 修改好后相机重启手机app重启进行连接。",
              "拍摄的视频手机无法保存：下载DJI Mimo应用程序打开后，请把app所需的权限全部允许，如拒绝的情况可能会出现无法保存图像的情况。",
              "如还有其他状况问题请及时联系客服售后进行处理解决。"
            ]
          },
          {
            "type": "code",
            "lang": "bash",
            "text": "# 查看设备 SN 码（位于机身底部标签或相机设置内查看）\nSN: 5WXXXXXXXXXXXXX"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[DJI Mimo](https://www.dji.com/cn/downloads/djiapp/dji-mimo)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 DJI Mimo，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },

  
/* ---------- 运动相机目录第一列（需增加复制以下整体进行修改即可） ----------
*/

  // 子目录内容：运动相机 · 影石ACEpro2
  "action-standard": {
    "desc": "影石 Ace Pro 2 标准版简易使用教程",
    "keywords": "影石 Ace Pro 2 运动相机 开机 拍照 录像 充电 电池 内存卡",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "Ace Pro 2 用起来不复杂，先记住电源键、快门键和翻转屏的位置，后面操作就简单了。"
          },
          {
            "type": "img",
            "src": "images/camera-buttons-original.svg",
            "alt": "Insta360 Ace Pro 2 按键示意图",
            "caption": "官方按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源键：短按开机，再点一下可以切换拍摄模式。",
              "长按电源键约 1 秒即可关机。",
              "快门键：拍照、开始录像和停止录像都用它。",
              "翻转屏：同时按屏幕两侧的按键，就可以把屏幕翻起来。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次拿到相机，建议先充满电再使用，避免拍到一半没电。"
          }
        ]
      },
      {
        "title": "安装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "先把电池和内存卡装好，再开机使用。安装前记得让相机处于关机状态。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "安装电池步骤图",
            "caption": "官方电池安装步骤"
          },
          {
            "type": "olist",
            "items": [
              "打开相机侧边的电池仓保护盖。",
              "按照电池上的方向标记，把电池平稳推进电池仓。",
              "盖好电池仓盖，确认黄色标线没有露出来。",
              "打开 MicroSD 卡槽盖，把内存卡按方向插入，听到轻轻一声后即可。"
            ]
          },
          {
            "type": "warn",
            "text": "请使用官方电池。内存卡建议使用正规品牌的高速卡，避免录像时提示卡速不足。"
          }
        ]
      },
      {
        "title": "开机和简单设置",
        "icon": "⚙️",
        "body": [
          {
            "type": "p",
            "text": "短按电源键开机。第一次使用，按照屏幕提示选择语言和时间即可。"
          },
          {
            "type": "list",
            "items": [
              "屏幕中间左右滑：切换拍摄模式。",
              "屏幕顶部向下滑：打开相机设置。",
              "屏幕左侧向右滑：进入相册。",
              "屏幕底部向上滑：调整拍摄参数。"
            ]
          },
          {
            "type": "tip",
            "text": "固定机位长时间拍摄，可以在菜单里打开“长续航模式”，但部分语音和手势功能会暂时不能用。"
          }
        ]
      },
      {
        "title": "开拍很简单",
        "icon": "🎬",
        "body": [
          {
            "type": "p",
            "text": "开机后，屏幕里能看到画面就表示可以拍摄了。"
          },
          {
            "type": "olist",
            "items": [
              "按一下快门键开始录像，再按一下停止录像。",
              "在屏幕中间左右滑动，可以切换录像、拍照、慢动作等模式。",
              "双击屏幕或点右下角按钮，可以在 1 倍和 2 倍画面之间切换。",
              "从屏幕顶部向下滑，可以打开设置和快捷功能。"
            ]
          },
          {
            "type": "tip",
            "text": "如果担心错过精彩画面，可以打开“预录制”，它会保存按下快门前的一段视频。"
          }
        ]
      },
      {
        "title": "充电、导出和保养",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机没电时，用 USB-C 充电线连接充电头即可充电。想导出照片和视频，可以用数据线连接电脑，也可以连接手机 App。"
          },
          {
            "type": "list",
            "items": [
              "连接电脑时，相机选择“U盘模式”，电脑里会出现相机文件夹。",
              "连接手机时，先在手机安装 Insta360 App，再根据相机提示连接。",
              "长时间不用时，每隔约 3 个月给电池充一次电。",
              "镜头有灰尘时，用气吹或镜头布清理，不要用硬物刮擦。"
            ]
          },
          {
            "type": "warn",
            "text": "下水前一定要确认电池仓盖、USB 盖和镜头保护镜都装紧。麦克风防风罩不要带去潜水或冲浪。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  /* 运动相机 Vlog 套装独立教程内容 */
  // 子目录内容：运动相机 · 影石ACEpro2手持lvog套装
  "action-vlog": {
    "desc": "影石 Ace Pro 2 手持 Vlog 套装简易使用教程",
    "keywords": "影石 Ace Pro 2 手持Vlog套装 自拍杆 运动相机 拍Vlog 录像 充电",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "Ace Pro 2 用起来不复杂，先记住电源键、快门键和翻转屏的位置，后面操作就简单了。"
          },
          {
            "type": "img",
            "src": "images/camera-buttons-original.svg",
            "alt": "Insta360 Ace Pro 2 按键示意图",
            "caption": "官方按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源键：短按开机，再点一下可以切换拍摄模式。",
              "长按电源键约 1 秒即可关机。",
              "快门键：拍照、开始录像和停止录像都用它。",
              "翻转屏：同时按屏幕两侧的按键，就可以把屏幕翻起来。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次拿到相机，建议先充满电再使用，避免拍到一半没电。"
          }
        ]
      },
      {
        "title": "安装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "先把电池和内存卡装好，再开机使用。安装前记得让相机处于关机状态。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "安装电池步骤图",
            "caption": "官方电池安装步骤"
          },
          {
            "type": "olist",
            "items": [
              "打开相机侧边的电池仓保护盖。",
              "按照电池上的方向标记，把电池平稳推进电池仓。",
              "盖好电池仓盖，确认黄色标线没有露出来。",
              "打开 MicroSD 卡槽盖，把内存卡按方向插入，听到轻轻一声后即可。"
            ]
          },
          {
            "type": "warn",
            "text": "请使用官方电池。内存卡建议使用正规品牌的高速卡，避免录像时提示卡速不足。"
          }
        ]
      },
      {
        "title": "安装手持支架",
        "icon": "🔧",
        "body": [
          {
            "type": "p",
            "text": "手持 Vlog 套装适合自拍、旅行记录和边走边拍，安装好支架后可以把相机举到合适的位置。"
          },
          {
            "type": "img",
            "src": "images/camera-quick-release-original.svg",
            "alt": "快拆底座安装步骤图",
            "caption": "官方快拆底座安装步骤"
          },
          {
            "type": "olist",
            "items": [
              "把快拆底座装到相机底部，确认听到“咔哒”声。",
              "把底座连接到手持支架或自拍杆上并锁紧。",
              "打开支架，调整到适合自拍的角度。",
              "先拿稳再开机，避免相机晃动或碰到周围物品。"
            ]
          },
          {
            "type": "tip",
            "text": "伸长自拍杆后不要快速甩动，人多的景区和街道要注意周围是否安全。"
          }
        ]
      },
      {
        "title": "拍一段简单 Vlog",
        "icon": "🎙️",
        "body": [
          {
            "type": "olist",
            "items": [
              "按快门键开始录像，再按一下结束。",
              "左右滑动屏幕切换录像、拍照和慢动作。",
              "说话时尽量靠近相机，风大时建议装好防风罩。",
              "双击屏幕切换 2 倍画面，拍远景会更方便。",
              "打开手势控制后，可以用手势开始或停止录像。"
            ]
          },
          {
            "type": "tip",
            "text": "拍 Vlog 不用一次拍很长，分成几段短视频，后期挑选会更轻松。"
          }
        ]
      },
      {
        "title": "充电、导出和保养",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机没电时，用 USB-C 充电线连接充电头即可充电。想导出照片和视频，可以用数据线连接电脑，也可以连接手机 App。"
          },
          {
            "type": "list",
            "items": [
              "连接电脑时，相机选择“U盘模式”，电脑里会出现相机文件夹。",
              "连接手机时，先在手机安装 Insta360 App，再根据相机提示连接。",
              "长时间不用时，每隔约 3 个月给电池充一次电。",
              "镜头有灰尘时，用气吹或镜头布清理，不要用硬物刮擦。"
            ]
          },
          {
            "type": "warn",
            "text": "下水前一定要确认电池仓盖、USB 盖和镜头保护镜都装紧。麦克风防风罩不要带去潜水或冲浪。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：运动相机 · 影石ACEpro2街拍套装
  "action-street": {
    "desc": "影石 Ace Pro 2 街拍套装简易使用教程",
    "keywords": "影石 Ace Pro 2 街拍套装 街拍手柄 运动相机 拍照 录像 充电",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "Ace Pro 2 用起来不复杂，先记住电源键、快门键和翻转屏的位置，后面操作就简单了。"
          },
          {
            "type": "img",
            "src": "images/camera-buttons-original.svg",
            "alt": "Insta360 Ace Pro 2 按键示意图",
            "caption": "官方按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源键：短按开机，再点一下可以切换拍摄模式。",
              "长按电源键约 1 秒即可关机。",
              "快门键：拍照、开始录像和停止录像都用它。",
              "翻转屏：同时按屏幕两侧的按键，就可以把屏幕翻起来。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次拿到相机，建议先充满电再使用，避免拍到一半没电。"
          }
        ]
      },
      {
        "title": "安装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "先把电池和内存卡装好，再开机使用。安装前记得让相机处于关机状态。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "安装电池步骤图",
            "caption": "官方电池安装步骤"
          },
          {
            "type": "olist",
            "items": [
              "打开相机侧边的电池仓保护盖。",
              "按照电池上的方向标记，把电池平稳推进电池仓。",
              "盖好电池仓盖，确认黄色标线没有露出来。",
              "打开 MicroSD 卡槽盖，把内存卡按方向插入，听到轻轻一声后即可。"
            ]
          },
          {
            "type": "warn",
            "text": "请使用官方电池。内存卡建议使用正规品牌的高速卡，避免录像时提示卡速不足。"
          }
        ]
      },
      {
        "title": "连接街拍手柄",
        "icon": "🧩",
        "body": [
          {
            "type": "p",
            "text": "街拍手柄连接好后，拍照和录像会更顺手，握持也更稳。"
          },
          {
            "type": "img",
            "src": "images/camera-handgrip-original.svg",
            "alt": "Insta360 Ace Pro 2 专业街拍手柄",
            "caption": "官方专业街拍手柄"
          },
          {
            "type": "olist",
            "items": [
              "把街拍手柄的 Type-C 插头接到相机接口。",
              "连接后按一下手柄快门键，确认相机能正常响应。",
              "如果屏幕提示“未连接”，长按手柄快门键约 8 秒重置，再重新连接。",
              "手柄长时间不用会休眠，点一下快门键就可以唤醒。"
            ]
          },
          {
            "type": "tip",
            "text": "建议用长按手柄快门键的方式开机，连接会更稳定。街拍手柄不防水，雨天和涉水场景要注意保护。"
          }
        ]
      },
      {
        "title": "街拍时怎么拍",
        "icon": "🚶",
        "body": [
          {
            "type": "p",
            "text": "边走边拍时，双手握稳手柄，眼睛看屏幕确认画面。"
          },
          {
            "type": "olist",
            "items": [
              "按快门键开始或停止录像。",
              "只拍瞬间画面时，直接按快门拍照。",
              "需要看清远处时，双击屏幕切换到 2 倍画面。",
              "担心错过画面时，打开预录制功能。"
            ]
          },
          {
            "type": "warn",
            "text": "骑行或走路拍摄时，不要一直盯着屏幕，要注意周围车辆和行人。"
          }
        ]
      },
      {
        "title": "充电、导出和保养",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机没电时，用 USB-C 充电线连接充电头即可充电。想导出照片和视频，可以用数据线连接电脑，也可以连接手机 App。"
          },
          {
            "type": "list",
            "items": [
              "连接电脑时，相机选择“U盘模式”，电脑里会出现相机文件夹。",
              "连接手机时，先在手机安装 Insta360 App，再根据相机提示连接。",
              "长时间不用时，每隔约 3 个月给电池充一次电。",
              "镜头有灰尘时，用气吹或镜头布清理，不要用硬物刮擦。"
            ]
          },
          {
            "type": "warn",
            "text": "下水前一定要确认电池仓盖、USB 盖和镜头保护镜都装紧。麦克风防风罩不要带去潜水或冲浪。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：运动相机 · 影石ACEpro2挂脖套装
  "action-neck": {
    "desc": "影石 Ace Pro 2 挂脖套装简易使用教程",
    "keywords": "影石 Ace Pro 2 挂脖套装 第一视角 运动相机 拍照 录像 充电",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "Ace Pro 2 用起来不复杂，先记住电源键、快门键和翻转屏的位置，后面操作就简单了。"
          },
          {
            "type": "img",
            "src": "images/camera-buttons-original.svg",
            "alt": "Insta360 Ace Pro 2 按键示意图",
            "caption": "官方按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源键：短按开机，再点一下可以切换拍摄模式。",
              "长按电源键约 1 秒即可关机。",
              "快门键：拍照、开始录像和停止录像都用它。",
              "翻转屏：同时按屏幕两侧的按键，就可以把屏幕翻起来。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次拿到相机，建议先充满电再使用，避免拍到一半没电。"
          }
        ]
      },
      {
        "title": "安装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "先把电池和内存卡装好，再开机使用。安装前记得让相机处于关机状态。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "安装电池步骤图",
            "caption": "官方电池安装步骤"
          },
          {
            "type": "olist",
            "items": [
              "打开相机侧边的电池仓保护盖。",
              "按照电池上的方向标记，把电池平稳推进电池仓。",
              "盖好电池仓盖，确认黄色标线没有露出来。",
              "打开 MicroSD 卡槽盖，把内存卡按方向插入，听到轻轻一声后即可。"
            ]
          },
          {
            "type": "warn",
            "text": "请使用官方电池。内存卡建议使用正规品牌的高速卡，避免录像时提示卡速不足。"
          }
        ]
      },
      {
        "title": "安装挂脖支架",
        "icon": "📿",
        "body": [
          {
            "type": "p",
            "text": "挂脖套装适合做饭、骑车、手工等第一视角拍摄，安装好以后不用一直用手拿相机。"
          },
          {
            "type": "img",
            "src": "images/camera-quick-release-original.svg",
            "alt": "快拆底座安装步骤图",
            "caption": "官方快拆底座安装步骤"
          },
          {
            "type": "olist",
            "items": [
              "先把快拆底座吸附到相机底部，按压到听见“咔哒”声。",
              "用手轻轻拉一下，确认底座没有松动。",
              "把快拆底座装到挂脖支架的接口上并锁紧。",
              "把挂脖支架挂在脖子上，调整到胸前合适的位置。"
            ]
          },
          {
            "type": "warn",
            "text": "调节时不要夹到衣服和头发，也不要影响呼吸。剧烈运动前先检查卡扣是否锁紧。"
          }
        ]
      },
      {
        "title": "第一视角拍摄",
        "icon": "🎥",
        "body": [
          {
            "type": "p",
            "text": "相机固定好后，先用屏幕确认画面是否水平，再开始拍摄。"
          },
          {
            "type": "olist",
            "items": [
              "按快门键开始录像，再按一下停止。",
              "左右滑动屏幕可以切换拍照和录像。",
              "双手不方便时，可以打开手势控制，用手掌开始或停止录像。",
              "做饭或手工拍摄时，建议先试拍一小段，确认画面没有被手臂挡住。"
            ]
          },
          {
            "type": "tip",
            "text": "挂脖支架不防水，相机自身支持防水，但下水前仍要确认所有保护盖已经锁紧。"
          }
        ]
      },
      {
        "title": "充电、导出和保养",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "相机没电时，用 USB-C 充电线连接充电头即可充电。想导出照片和视频，可以用数据线连接电脑，也可以连接手机 App。"
          },
          {
            "type": "list",
            "items": [
              "连接电脑时，相机选择“U盘模式”，电脑里会出现相机文件夹。",
              "连接手机时，先在手机安装 Insta360 App，再根据相机提示连接。",
              "长时间不用时，每隔约 3 个月给电池充一次电。",
              "镜头有灰尘时，用气吹或镜头布清理，不要用硬物刮擦。"
            ]
          },
          {
            "type": "warn",
            "text": "下水前一定要确认电池仓盖、USB 盖和镜头保护镜都装紧。麦克风防风罩不要带去潜水或冲浪。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：微单相机 · 佳能微单+18-45mm入门套镜头
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  // 子目录内容：全景相机 · 影石Insta360 X6标准版
  "insta360-x6-standard": {
    "desc": "影石Insta360 X6标准版简易使用教程",
    "keywords": "影石 Insta360 X6 全景相机 8K 电池 充电 内存卡 App",
    "steps": [
      {
        "title": "先认识 X6",
        "icon": "🌐",
        "body": [
          {
            "type": "p",
            "text": "X6 有两个镜头，能一次记录周围 360° 的画面。拍完以后可以在手机里自由选择想看的视角。"
          },
          {
            "type": "img",
            "src": "images/insta360-x6-standard-original.svg",
            "alt": "Insta360 X6 全景相机示意图",
            "caption": "原创全景相机示意图"
          },
          {
            "type": "list",
            "items": [
              "两个镜头：拍摄时不要用手摸镜片。",
              "触摸屏：查看画面、切换模式和调整设置。",
              "快门键：开始和停止拍摄。",
              "Type-C 接口：给相机充电和连接电脑。",
              "内置存储：X6 可用约 47GB，忘记带内存卡也能先拍。"
            ]
          },
          {
            "type": "warn",
            "text": "两个镜头都关系到全景画面，使用时避免磕碰。镜片破裂或固定环变形时不要自己拆，直接联系售后。"
          }
        ]
      },
      {
        "title": "充电和存储",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "X6 使用 Type-C 充电。推荐使用支持 PD 3.0 PPS 的 30W 充电器，充电速度会更快。"
          },
          {
            "type": "list",
            "items": [
              "约 24 分钟可以充到 80%，约 35 分钟充满。",
              "建议使用 UHS-I V30 或更高等级的 microSD 卡。",
              "卡槽方向和缺口对准后再插入，不要硬推。",
              "内置存储快满时，先把素材导出到手机或电脑。"
            ]
          },
          {
            "type": "tip",
            "text": "边充边拍会让机身更热，建议保持通风。"
          }
        ]
      },
      {
        "title": "开机和屏幕操作",
        "icon": "⚙️",
        "body": [
          {
            "type": "p",
            "text": "点按电源键开机，屏幕亮起后就可以查看画面。X6 使用虚拟按键，很多操作可以直接在屏幕上完成。"
          },
          {
            "type": "olist",
            "items": [
              "点按电源键开机，再点按可切换拍摄模式。",
              "左右滑动屏幕切换全景视频、全景照片等模式。",
              "从屏幕边缘滑动进入设置、相册或拍摄参数。",
              "开始拍摄前，先确认两个镜头都没有被手指或配件挡住。"
            ]
          },
          {
            "type": "tip",
            "text": "屏幕按键不需要用力按压，轻触或滑动即可。"
          }
        ]
      },
      {
        "title": "拍全景和导出",
        "icon": "🎬",
        "body": [
          {
            "type": "olist",
            "items": [
              "选择全景视频或全景照片模式。",
              "按快门开始拍摄，再按一下停止。",
              "拍摄时尽量保持相机稳定，手拿自拍杆转动更容易保持水平。",
              "打开手机蓝牙和 Wi-Fi，使用 Insta360 App 连接 X6。",
              "在 App 里导出素材，并自由改变画面方向、比例和视角。"
            ]
          },
          {
            "type": "p",
            "text": "[查看影石 Insta360 X6 官方教程](https://onlinemanual.insta360.com/x6/zh-cn)"
          },
          {
            "type": "tip",
            "text": "全景素材不要直接在普通播放器里看，使用 Insta360 App 或官方 Studio 工具才能自由转动视角。"
          }
        ]
      },
      {
        "title": "镜头和日常保养",
        "icon": "🧰",
        "body": [
          {
            "type": "list",
            "items": [
              "镜头有灰尘时，先用气吹，再用干净镜头布轻擦。",
              "不要用衣服、纸巾或手指反复摩擦镜片。",
              "只在镜片有刮痕时使用官方维修套装更换，破裂请直接联系售后。",
              "海边使用后，用淡水湿布擦净机身并晾干。",
              "长期不用时，放在干燥阴凉处并定期充电。"
            ]
          },
          {
            "type": "p",
            "text": "[查看 Insta360 X6 官方产品页](https://www.insta360.com/cn/product/insta360-x6)"
          },
          {
            "type": "warn",
            "text": "水下或雨天使用前，确认接口盖、电池盖和镜头保护件都安装到位。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：全景相机 · 影石Insta360 X6全能版
  "insta360-x6-allround": {
    "desc": "影石Insta360 X6全能版简易使用教程",
    "keywords": "影石 Insta360 X6 全能版 配件 电池 手柄 全景相机",
    "steps": [
      {
        "title": "先认识 X6",
        "icon": "🌐",
        "body": [
          {
            "type": "p",
            "text": "X6 有两个镜头，能一次记录周围 360° 的画面。拍完以后可以在手机里自由选择想看的视角。"
          },
          {
            "type": "img",
            "src": "images/insta360-x6-standard-original.svg",
            "alt": "Insta360 X6 全景相机示意图",
            "caption": "原创全景相机示意图"
          },
          {
            "type": "list",
            "items": [
              "两个镜头：拍摄时不要用手摸镜片。",
              "触摸屏：查看画面、切换模式和调整设置。",
              "快门键：开始和停止拍摄。",
              "Type-C 接口：给相机充电和连接电脑。",
              "内置存储：X6 可用约 47GB，忘记带内存卡也能先拍。"
            ]
          },
          {
            "type": "warn",
            "text": "两个镜头都关系到全景画面，使用时避免磕碰。镜片破裂或固定环变形时不要自己拆，直接联系售后。"
          }
        ]
      },
      {
        "title": "充电和存储",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "X6 使用 Type-C 充电。推荐使用支持 PD 3.0 PPS 的 30W 充电器，充电速度会更快。"
          },
          {
            "type": "list",
            "items": [
              "约 24 分钟可以充到 80%，约 35 分钟充满。",
              "建议使用 UHS-I V30 或更高等级的 microSD 卡。",
              "卡槽方向和缺口对准后再插入，不要硬推。",
              "内置存储快满时，先把素材导出到手机或电脑。"
            ]
          },
          {
            "type": "tip",
            "text": "边充边拍会让机身更热，建议保持通风。"
          }
        ]
      },
      {
        "title": "使用全能版配件",
        "icon": "🎒",
        "body": [
          {
            "type": "p",
            "text": "全能版配件以实际收到的套装为准，常见配件主要用来增加续航、稳定性和拍摄机位。"
          },
          {
            "type": "img",
            "src": "images/insta360-x6-allround-original.svg",
            "alt": "Insta360 X6 全能版配件示意图",
            "caption": "原创全能版配件示意图"
          },
          {
            "type": "list",
            "items": [
              "备用电池：长时间拍摄时轮换使用。",
              "扩展手柄：手持和自拍时更稳。",
              "充电管家：方便同时整理和充电多块电池。",
              "收纳包：不用时保护相机和镜头。"
            ]
          },
          {
            "type": "tip",
            "text": "安装配件时不要挡住镜头，也不要把过重的设备挂在相机上。"
          }
        ]
      },
      {
        "title": "拍全景和导出",
        "icon": "🎬",
        "body": [
          {
            "type": "olist",
            "items": [
              "选择全景视频或全景照片模式。",
              "按快门开始拍摄，再按一下停止。",
              "拍摄时尽量保持相机稳定，手拿自拍杆转动更容易保持水平。",
              "打开手机蓝牙和 Wi-Fi，使用 Insta360 App 连接 X6。",
              "在 App 里导出素材，并自由改变画面方向、比例和视角。"
            ]
          },
          {
            "type": "p",
            "text": "[查看影石 Insta360 X6 官方教程](https://onlinemanual.insta360.com/x6/zh-cn)"
          },
          {
            "type": "tip",
            "text": "全景素材不要直接在普通播放器里看，使用 Insta360 App 或官方 Studio 工具才能自由转动视角。"
          }
        ]
      },
      {
        "title": "镜头和日常保养",
        "icon": "🧰",
        "body": [
          {
            "type": "list",
            "items": [
              "镜头有灰尘时，先用气吹，再用干净镜头布轻擦。",
              "不要用衣服、纸巾或手指反复摩擦镜片。",
              "只在镜片有刮痕时使用官方维修套装更换，破裂请直接联系售后。",
              "海边使用后，用淡水湿布擦净机身并晾干。",
              "长期不用时，放在干燥阴凉处并定期充电。"
            ]
          },
          {
            "type": "p",
            "text": "[查看 Insta360 X6 官方产品页](https://www.insta360.com/cn/product/insta360-x6)"
          },
          {
            "type": "warn",
            "text": "水下或雨天使用前，确认接口盖、电池盖和镜头保护件都安装到位。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：全景相机 · 影石Insta360 X6旅拍套装
  "insta360-x6-travel": {
    "desc": "影石Insta360 X6旅拍套装简易使用教程",
    "keywords": "影石 Insta360 X6 旅拍套装 自拍杆 三脚架 全景相机",
    "steps": [
      {
        "title": "先认识 X6",
        "icon": "🌐",
        "body": [
          {
            "type": "p",
            "text": "X6 有两个镜头，能一次记录周围 360° 的画面。拍完以后可以在手机里自由选择想看的视角。"
          },
          {
            "type": "img",
            "src": "images/insta360-x6-standard-original.svg",
            "alt": "Insta360 X6 全景相机示意图",
            "caption": "原创全景相机示意图"
          },
          {
            "type": "list",
            "items": [
              "两个镜头：拍摄时不要用手摸镜片。",
              "触摸屏：查看画面、切换模式和调整设置。",
              "快门键：开始和停止拍摄。",
              "Type-C 接口：给相机充电和连接电脑。",
              "内置存储：X6 可用约 47GB，忘记带内存卡也能先拍。"
            ]
          },
          {
            "type": "warn",
            "text": "两个镜头都关系到全景画面，使用时避免磕碰。镜片破裂或固定环变形时不要自己拆，直接联系售后。"
          }
        ]
      },
      {
        "title": "充电和存储",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "X6 使用 Type-C 充电。推荐使用支持 PD 3.0 PPS 的 30W 充电器，充电速度会更快。"
          },
          {
            "type": "list",
            "items": [
              "约 24 分钟可以充到 80%，约 35 分钟充满。",
              "建议使用 UHS-I V30 或更高等级的 microSD 卡。",
              "卡槽方向和缺口对准后再插入，不要硬推。",
              "内置存储快满时，先把素材导出到手机或电脑。"
            ]
          },
          {
            "type": "tip",
            "text": "边充边拍会让机身更热，建议保持通风。"
          }
        ]
      },
      {
        "title": "旅拍套装使用",
        "icon": "✈️",
        "body": [
          {
            "type": "p",
            "text": "旅拍套装适合旅行、Vlog 和多人合影，通常搭配自拍杆、三脚架和收纳包，以实际套装为准。"
          },
          {
            "type": "img",
            "src": "images/insta360-x6-travel-original.svg",
            "alt": "Insta360 X6 旅拍套装示意图",
            "caption": "原创旅拍套装示意图"
          },
          {
            "type": "olist",
            "items": [
              "把相机固定到自拍杆或三脚架上，确认螺丝拧紧。",
              "先试拍一小段，检查相机有没有挡镜头。",
              "拍全景视频时慢慢移动，画面后期更容易调整。",
              "旅行结束后先备份素材，再清空内存卡。"
            ]
          },
          {
            "type": "tip",
            "text": "人多的地方使用自拍杆时，注意周围行人，避免碰到别人或相机。"
          }
        ]
      },
      {
        "title": "拍全景和导出",
        "icon": "🎬",
        "body": [
          {
            "type": "olist",
            "items": [
              "选择全景视频或全景照片模式。",
              "按快门开始拍摄，再按一下停止。",
              "拍摄时尽量保持相机稳定，手拿自拍杆转动更容易保持水平。",
              "打开手机蓝牙和 Wi-Fi，使用 Insta360 App 连接 X6。",
              "在 App 里导出素材，并自由改变画面方向、比例和视角。"
            ]
          },
          {
            "type": "p",
            "text": "[查看影石 Insta360 X6 官方教程](https://onlinemanual.insta360.com/x6/zh-cn)"
          },
          {
            "type": "tip",
            "text": "全景素材不要直接在普通播放器里看，使用 Insta360 App 或官方 Studio 工具才能自由转动视角。"
          }
        ]
      },
      {
        "title": "镜头和日常保养",
        "icon": "🧰",
        "body": [
          {
            "type": "list",
            "items": [
              "镜头有灰尘时，先用气吹，再用干净镜头布轻擦。",
              "不要用衣服、纸巾或手指反复摩擦镜片。",
              "只在镜片有刮痕时使用官方维修套装更换，破裂请直接联系售后。",
              "海边使用后，用淡水湿布擦净机身并晾干。",
              "长期不用时，放在干燥阴凉处并定期充电。"
            ]
          },
          {
            "type": "p",
            "text": "[查看 Insta360 X6 官方产品页](https://www.insta360.com/cn/product/insta360-x6)"
          },
          {
            "type": "warn",
            "text": "水下或雨天使用前，确认接口盖、电池盖和镜头保护件都安装到位。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Insta360 App](https://www.insta360.com/cn/download)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Insta360 App，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  "mirrorless-entry": {
    "desc": "佳能微单 + 18-45mm 入门套机简易教程",
    "keywords": "佳能微单 R50 18-45mm 入门 拍照 录像 电池 内存卡",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "佳能微单看着按键多，其实常用功能就几个。先认准电源、快门、模式转盘和屏幕，拍起来就不难。"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-front-original.svg",
            "alt": "佳能 EOS R50 机身正面部件图",
            "caption": "官方机身正面部件图"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-back-original.svg",
            "alt": "佳能 EOS R50 机背按键图",
            "caption": "官方机背按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源开关：开机和关机。",
              "快门按钮：拍照用；轻按对焦，按到底拍照。",
              "短片拍摄按钮：按一下开始录像，再按一下停止。",
              "模式转盘：新手先放在绿色 A+ 全自动模式。",
              "回放按钮：用来查看已经拍好的照片和视频。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次使用前先给电池充电。电池充满后，充电器的指示灯会变绿。"
          }
        ]
      },
      {
        "title": "装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "相机底部是电池和内存卡的仓盖。安装前先关机，避免相机读不到卡。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "佳能 EOS R50 电池和存储卡安装图",
            "caption": "官方电池与存储卡安装示意"
          },
          {
            "type": "olist",
            "items": [
              "打开电池仓盖。",
              "按电池仓里的方向标记，把电池平稳放进去。",
              "打开旁边的内存卡槽，把卡按方向插到底。",
              "盖好仓盖，确认卡扣已经扣紧。"
            ]
          },
          {
            "type": "warn",
            "text": "不要强行插电池和内存卡。方向不对时不要硬按，翻个方向再试。"
          }
        ]
      },
      {
        "title": "安装18-45mm镜头",
        "icon": "🔘",
        "body": [
          {
            "type": "p",
            "text": "这个镜头适合日常、旅行和 Vlog，安装镜头时一定要先关机。"
          },
          {
            "type": "img",
            "src": "images/camera-lens-mount-original.svg",
            "alt": "佳能 RF 镜头安装图",
            "caption": "官方镜头安装示意"
          },
          {
            "type": "olist",
            "items": [
              "取下机身盖和镜头后盖。",
              "把镜头上的红点对准机身上的红点。",
              "轻轻放入后顺时针转动，听到“咔哒”声就装好了。",
              "拆镜头时按住镜头释放按钮，再逆时针转动。"
            ]
          },
          {
            "type": "tip",
            "text": "18mm 拍风景和室内更宽敞，45mm 拍人像和近景更自然。"
          }
        ]
      },
      {
        "title": "用全自动模式拍照",
        "icon": "📸",
        "body": [
          {
            "type": "p",
            "text": "新手直接把模式转盘转到绿色 A+，相机会自动帮你调好亮度、对焦和颜色。"
          },
          {
            "type": "img",
            "src": "images/camera-auto-mode-original.svg",
            "alt": "佳能 EOS R50 全自动模式图",
            "caption": "官方全自动拍摄模式"
          },
          {
            "type": "olist",
            "items": [
              "眼睛看屏幕取景，想让哪里清楚就点一下屏幕上的位置。",
              "轻按快门对焦，按到底完成拍照。",
              "按短片拍摄按钮开始录像，再按一下停止。",
              "转动镜头变焦环，可以拉近或拉远画面。"
            ]
          },
          {
            "type": "tip",
            "text": "拍完以后按回放按钮就能查看照片。照片不满意可以直接删除，再重新拍。"
          }
        ]
      },
      {
        "title": "传照片和日常保养",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "想把照片传到手机，可以安装佳能 Camera Connect，也可以用读卡器把内存卡插到电脑上。"
          },
          {
            "type": "img",
            "src": "images/camera-phone-connect-original.svg",
            "alt": "佳能 Camera Connect 连接手机示意图",
            "caption": "官方手机连接示意"
          },
          {
            "type": "olist",
            "items": [
              "手机安装 Canon Camera Connect。",
              "打开相机 Wi-Fi 或蓝牙，按屏幕提示连接手机。",
              "进入相机上的图像，选择照片或视频保存到手机。",
              "用电脑时，取出内存卡，通过读卡器复制 DCIM 文件夹即可。"
            ]
          },
          {
            "type": "p",
            "text": "[打开佳能官方完整说明书](https://cam.start.canon/zh/C011/manual/html/index.html)"
          },
          {
            "type": "tip",
            "text": "镜头有灰尘时，先用气吹，再用镜头布轻擦。不要用衣服或纸巾用力擦镜头。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Canon Camera Connect](https://www.canon.com.cn/supports/download/app.html)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Canon Camera Connect，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：微单相机 · 佳能微单+18-150mm风光变焦镜头
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  "mirrorless-plus": {
    "desc": "佳能微单 + 18-150mm 风光变焦镜头简易教程",
    "keywords": "佳能微单 R50 18-150mm 风光 变焦 拍照 录像",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "佳能微单看着按键多，其实常用功能就几个。先认准电源、快门、模式转盘和屏幕，拍起来就不难。"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-front-original.svg",
            "alt": "佳能 EOS R50 机身正面部件图",
            "caption": "官方机身正面部件图"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-back-original.svg",
            "alt": "佳能 EOS R50 机背按键图",
            "caption": "官方机背按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源开关：开机和关机。",
              "快门按钮：拍照用；轻按对焦，按到底拍照。",
              "短片拍摄按钮：按一下开始录像，再按一下停止。",
              "模式转盘：新手先放在绿色 A+ 全自动模式。",
              "回放按钮：用来查看已经拍好的照片和视频。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次使用前先给电池充电。电池充满后，充电器的指示灯会变绿。"
          }
        ]
      },
      {
        "title": "装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "相机底部是电池和内存卡的仓盖。安装前先关机，避免相机读不到卡。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "佳能 EOS R50 电池和存储卡安装图",
            "caption": "官方电池与存储卡安装示意"
          },
          {
            "type": "olist",
            "items": [
              "打开电池仓盖。",
              "按电池仓里的方向标记，把电池平稳放进去。",
              "打开旁边的内存卡槽，把卡按方向插到底。",
              "盖好仓盖，确认卡扣已经扣紧。"
            ]
          },
          {
            "type": "warn",
            "text": "不要强行插电池和内存卡。方向不对时不要硬按，翻个方向再试。"
          }
        ]
      },
      {
        "title": "安装18-150mm镜头",
        "icon": "🔘",
        "body": [
          {
            "type": "p",
            "text": "这个镜头从广角到长焦都能拍，旅行时不用频繁换镜头。"
          },
          {
            "type": "img",
            "src": "images/camera-lens-mount-original.svg",
            "alt": "佳能 RF 镜头安装图",
            "caption": "官方镜头安装示意"
          },
          {
            "type": "olist",
            "items": [
              "关机后取下机身盖和镜头后盖。",
              "红点对准红点，放入镜头后顺时针转紧。",
              "听到“咔哒”声后，轻轻拉一下镜头确认没有松动。",
              "使用变焦环时慢慢转动，不要用力过猛。"
            ]
          },
          {
            "type": "tip",
            "text": "18mm 适合风景和大合影，150mm 适合拍远处的山、建筑和人物。"
          }
        ]
      },
      {
        "title": "拍风景和远处物体",
        "icon": "📸",
        "body": [
          {
            "type": "p",
            "text": "光线好时用全自动模式就能拍出清楚的照片，远处物体可以转动变焦环拉近。"
          },
          {
            "type": "img",
            "src": "images/camera-auto-mode-original.svg",
            "alt": "佳能 EOS R50 全自动模式图",
            "caption": "官方全自动拍摄模式"
          },
          {
            "type": "olist",
            "items": [
              "先用 18mm 拍一张大场景。",
              "再慢慢转到更长焦段，选择喜欢的局部画面。",
              "画面里有天空和地面时，点击屏幕中间偏亮的位置对焦。",
              "手持拍摄时双手拿稳，按快门时不要突然晃动。"
            ]
          },
          {
            "type": "tip",
            "text": "拍完以后按回放按钮就能查看照片。照片不满意可以直接删除，再重新拍。"
          }
        ]
      },
      {
        "title": "传照片和日常保养",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "想把照片传到手机，可以安装佳能 Camera Connect，也可以用读卡器把内存卡插到电脑上。"
          },
          {
            "type": "img",
            "src": "images/camera-phone-connect-original.svg",
            "alt": "佳能 Camera Connect 连接手机示意图",
            "caption": "官方手机连接示意"
          },
          {
            "type": "olist",
            "items": [
              "手机安装 Canon Camera Connect。",
              "打开相机 Wi-Fi 或蓝牙，按屏幕提示连接手机。",
              "进入相机上的图像，选择照片或视频保存到手机。",
              "用电脑时，取出内存卡，通过读卡器复制 DCIM 文件夹即可。"
            ]
          },
          {
            "type": "p",
            "text": "[打开佳能官方完整说明书](https://cam.start.canon/zh/C011/manual/html/index.html)"
          },
          {
            "type": "tip",
            "text": "镜头有灰尘时，先用气吹，再用镜头布轻擦。不要用衣服或纸巾用力擦镜头。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Canon Camera Connect](https://www.canon.com.cn/supports/download/app.html)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Canon Camera Connect，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：微单相机 · 佳能微单+F1.8人像大光圈镜头
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  "mirrorless-pro": {
    "desc": "佳能微单 + F1.8 人像大光圈镜头简易教程",
    "keywords": "佳能微单 F1.8 人像镜头 虚化 拍照 大光圈",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "佳能微单看着按键多，其实常用功能就几个。先认准电源、快门、模式转盘和屏幕，拍起来就不难。"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-front-original.svg",
            "alt": "佳能 EOS R50 机身正面部件图",
            "caption": "官方机身正面部件图"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-back-original.svg",
            "alt": "佳能 EOS R50 机背按键图",
            "caption": "官方机背按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源开关：开机和关机。",
              "快门按钮：拍照用；轻按对焦，按到底拍照。",
              "短片拍摄按钮：按一下开始录像，再按一下停止。",
              "模式转盘：新手先放在绿色 A+ 全自动模式。",
              "回放按钮：用来查看已经拍好的照片和视频。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次使用前先给电池充电。电池充满后，充电器的指示灯会变绿。"
          }
        ]
      },
      {
        "title": "装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "相机底部是电池和内存卡的仓盖。安装前先关机，避免相机读不到卡。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "佳能 EOS R50 电池和存储卡安装图",
            "caption": "官方电池与存储卡安装示意"
          },
          {
            "type": "olist",
            "items": [
              "打开电池仓盖。",
              "按电池仓里的方向标记，把电池平稳放进去。",
              "打开旁边的内存卡槽，把卡按方向插到底。",
              "盖好仓盖，确认卡扣已经扣紧。"
            ]
          },
          {
            "type": "warn",
            "text": "不要强行插电池和内存卡。方向不对时不要硬按，翻个方向再试。"
          }
        ]
      },
      {
        "title": "安装 F1.8 人像镜头",
        "icon": "🔘",
        "body": [
          {
            "type": "p",
            "text": "F1.8 镜头适合拍人像，可以把背景拍得柔柔的，人物更突出。"
          },
          {
            "type": "img",
            "src": "images/camera-lens-mount-original.svg",
            "alt": "佳能 RF 镜头安装图",
            "caption": "官方镜头安装示意"
          },
          {
            "type": "olist",
            "items": [
              "关机后取下机身盖和镜头后盖。",
              "红点对准红点，放入后顺时针转紧。",
              "确认听到“咔哒”声后再开机。",
              "拍摄时不要离人物太近，留出合适距离。"
            ]
          },
          {
            "type": "tip",
            "text": "想拍出背景虚化，可以把光圈数字调小，例如 F1.8、F2.0；数字越小，背景越柔。"
          }
        ]
      },
      {
        "title": "拍出简单的人像效果",
        "icon": "📸",
        "body": [
          {
            "type": "p",
            "text": "先让模特站在离背景远一点的位置，再把对焦点放在眼睛附近。"
          },
          {
            "type": "img",
            "src": "images/camera-auto-mode-original.svg",
            "alt": "佳能 EOS R50 全自动模式图",
            "caption": "官方全自动拍摄模式"
          },
          {
            "type": "olist",
            "items": [
              "模式转盘选择 Av 光圈优先。",
              "转动拨盘把光圈调到 F1.8 到 F2.8。",
              "点击屏幕上人物的眼睛位置进行对焦。",
              "轻轻按快门完成拍摄，注意人物表情和背景光线。"
            ]
          },
          {
            "type": "tip",
            "text": "拍完以后按回放按钮就能查看照片。照片不满意可以直接删除，再重新拍。"
          }
        ]
      },
      {
        "title": "传照片和日常保养",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "想把照片传到手机，可以安装佳能 Camera Connect，也可以用读卡器把内存卡插到电脑上。"
          },
          {
            "type": "img",
            "src": "images/camera-phone-connect-original.svg",
            "alt": "佳能 Camera Connect 连接手机示意图",
            "caption": "官方手机连接示意"
          },
          {
            "type": "olist",
            "items": [
              "手机安装 Canon Camera Connect。",
              "打开相机 Wi-Fi 或蓝牙，按屏幕提示连接手机。",
              "进入相机上的图像，选择照片或视频保存到手机。",
              "用电脑时，取出内存卡，通过读卡器复制 DCIM 文件夹即可。"
            ]
          },
          {
            "type": "p",
            "text": "[打开佳能官方完整说明书](https://cam.start.canon/zh/C011/manual/html/index.html)"
          },
          {
            "type": "tip",
            "text": "镜头有灰尘时，先用气吹，再用镜头布轻擦。不要用衣服或纸巾用力擦镜头。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Canon Camera Connect](https://www.canon.com.cn/supports/download/app.html)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Canon Camera Connect，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  /* 超远摄微单独立教程内容 */
  // 子目录内容：微单相机 · 佳能微单+超远摄100-400mm
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  "mirrorless-one": {
    "desc": "佳能微单 + 100-400mm 超远摄镜头简易教程",
    "keywords": "佳能微单 100-400mm 超远摄 长焦 拍鸟 拍演出",
    "steps": [
      {
        "title": "先认识相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "佳能微单看着按键多，其实常用功能就几个。先认准电源、快门、模式转盘和屏幕，拍起来就不难。"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-front-original.svg",
            "alt": "佳能 EOS R50 机身正面部件图",
            "caption": "官方机身正面部件图"
          },
          {
            "type": "img",
            "src": "images/camera-mirrorless-back-original.svg",
            "alt": "佳能 EOS R50 机背按键图",
            "caption": "官方机背按键示意图"
          },
          {
            "type": "list",
            "items": [
              "电源开关：开机和关机。",
              "快门按钮：拍照用；轻按对焦，按到底拍照。",
              "短片拍摄按钮：按一下开始录像，再按一下停止。",
              "模式转盘：新手先放在绿色 A+ 全自动模式。",
              "回放按钮：用来查看已经拍好的照片和视频。"
            ]
          },
          {
            "type": "tip",
            "text": "第一次使用前先给电池充电。电池充满后，充电器的指示灯会变绿。"
          }
        ]
      },
      {
        "title": "装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "相机底部是电池和内存卡的仓盖。安装前先关机，避免相机读不到卡。"
          },
          {
            "type": "img",
            "src": "images/camera-battery-card-original.svg",
            "alt": "佳能 EOS R50 电池和存储卡安装图",
            "caption": "官方电池与存储卡安装示意"
          },
          {
            "type": "olist",
            "items": [
              "打开电池仓盖。",
              "按电池仓里的方向标记，把电池平稳放进去。",
              "打开旁边的内存卡槽，把卡按方向插到底。",
              "盖好仓盖，确认卡扣已经扣紧。"
            ]
          },
          {
            "type": "warn",
            "text": "不要强行插电池和内存卡。方向不对时不要硬按，翻个方向再试。"
          }
        ]
      },
      {
        "title": "安装100-400mm镜头",
        "icon": "🔘",
        "body": [
          {
            "type": "p",
            "text": "这个镜头又长又重，适合拍远处的鸟、动物、舞台和运动。安装和拿取时都要稳。"
          },
          {
            "type": "img",
            "src": "images/camera-lens-mount-original.svg",
            "alt": "佳能 RF 镜头安装图",
            "caption": "官方镜头安装示意"
          },
          {
            "type": "olist",
            "items": [
              "关机后取下机身盖和镜头后盖。",
              "一手托住镜头，一手固定机身，红点对准后装紧。",
              "听到“咔哒”声后，确认镜头没有松动。",
              "拆卸时一手托镜头，一手按住镜头释放按钮。"
            ]
          },
          {
            "type": "tip",
            "text": "手持时最好双手托住镜头；拍摄远处时可以靠着栏杆，或者使用三脚架，会更稳。"
          }
        ]
      },
      {
        "title": "拍远处物体的小技巧",
        "icon": "📸",
        "body": [
          {
            "type": "p",
            "text": "第一次用长焦镜头不要一直拉到最长，先从 100mm 左右开始找目标。"
          },
          {
            "type": "img",
            "src": "images/camera-auto-mode-original.svg",
            "alt": "佳能 EOS R50 全自动模式图",
            "caption": "官方全自动拍摄模式"
          },
          {
            "type": "olist",
            "items": [
              "把镜头对准远处物体，慢慢转动变焦环拉近。",
              "打开镜头防抖开关，如果镜头上带有 IS 或 STABILIZER。",
              "点击屏幕目标位置对焦，按快门时轻轻呼吸。",
              "光线不够时尽量找亮一点的位置，或者使用支架拍摄。"
            ]
          },
          {
            "type": "tip",
            "text": "拍完以后按回放按钮就能查看照片。照片不满意可以直接删除，再重新拍。"
          }
        ]
      },
      {
        "title": "传照片和日常保养",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "想把照片传到手机，可以安装佳能 Camera Connect，也可以用读卡器把内存卡插到电脑上。"
          },
          {
            "type": "img",
            "src": "images/camera-phone-connect-original.svg",
            "alt": "佳能 Camera Connect 连接手机示意图",
            "caption": "官方手机连接示意"
          },
          {
            "type": "olist",
            "items": [
              "手机安装 Canon Camera Connect。",
              "打开相机 Wi-Fi 或蓝牙，按屏幕提示连接手机。",
              "进入相机上的图像，选择照片或视频保存到手机。",
              "用电脑时，取出内存卡，通过读卡器复制 DCIM 文件夹即可。"
            ]
          },
          {
            "type": "p",
            "text": "[打开佳能官方完整说明书](https://cam.start.canon/zh/C011/manual/html/index.html)"
          },
          {
            "type": "tip",
            "text": "镜头有灰尘时，先用气吹，再用镜头布轻擦。不要用衣服或纸巾用力擦镜头。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Canon Camera Connect](https://www.canon.com.cn/supports/download/app.html)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Canon Camera Connect，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：卡片相机 · 佳能卡片相机标准版
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  "compact-entry": {
    "desc": "佳能 G7 X Mark III 标准版简易使用教程",
    "keywords": "佳能 G7X3 卡片相机 拍照 录像 电池 内存卡 Wi-Fi 传照片",
    "steps": [
      {
        "title": "先认识这台相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "佳能 G7 X Mark III 是一台小巧的卡片相机，镜头不用拆装，开机就能拍，特别适合旅行和日常记录。"
          },
          {
            "type": "img",
            "src": "images/camera-compact-original.svg",
            "alt": "佳能 G7 X Mark III 官方使用说明书",
            "caption": "佳能官方 G7 X Mark III 使用说明书"
          },
          {
            "type": "list",
            "items": [
              "电源键：开机和关机。",
              "快门键：拍照；轻按对焦，按到底完成拍摄。",
              "红色短片键：开始和停止录像。",
              "变焦杆：拉近或拉远画面。",
              "回放键：查看拍好的照片和视频。"
            ]
          },
          {
            "type": "tip",
            "text": "新手先把模式转盘转到绿色 A+ 全自动，相机会自动调好亮度和颜色。"
          }
        ]
      },
      {
        "title": "安装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "相机底部是电池和内存卡仓。安装前先关机，按里面的方向标记放入即可。"
          },
          {
            "type": "olist",
            "items": [
              "打开底部仓盖。",
              "把官方电池按方向放进去，轻轻推到底。",
              "把 SD 内存卡按方向插入卡槽，听到轻微一声即可。",
              "盖好仓盖，确认卡扣锁紧。"
            ]
          },
          {
            "type": "warn",
            "text": "不要用力硬插电池或内存卡。相机提示卡速不足时，建议更换正规品牌的高速 SD 卡。"
          }
        ]
      },
      {
        "title": "开机和基础设置",
        "icon": "⚙️",
        "body": [
          {
            "type": "p",
            "text": "第一次开机后，按照屏幕提示选择语言、日期和时间。设置完成后就可以开始拍摄。"
          },
          {
            "type": "olist",
            "items": [
              "轻按快门键，相机就会自动对焦。",
              "用手指点屏幕，可以指定要对焦的位置。",
              "转动模式转盘选择拍照、自动或短片模式。",
              "向上翻开屏幕，可以自拍和低角度拍摄。",
              "不需要闪光灯时可以保持关闭，光线暗时再按闪光键打开。"
            ]
          },
          {
            "type": "tip",
            "text": "拍照前先确认屏幕上的电量和剩余可拍张数，避免拍到一半没电或内存不足。"
          }
        ]
      },
      {
        "title": "拍照和录像",
        "icon": "🎬",
        "body": [
          {
            "type": "p",
            "text": "G7 X Mark III 的拍照和录像都很简单，主要用快门键和红色短片键。"
          },
          {
            "type": "olist",
            "items": [
              "拍照：轻按快门对焦，按到底拍照。",
              "录像：按一下红色短片键开始，再按一下停止。",
              "使用变焦杆调整远近，拍完再按回放键查看。",
              "拍人像时点击人物脸部附近，让相机准确对焦。"
            ]
          },
          {
            "type": "tip",
            "text": "光线暗时尽量保持双手稳定；也可以靠着桌子、栏杆或使用小型三脚架。"
          }
        ]
      },
      {
        "title": "传照片和日常保养",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "照片可以传到手机，也可以把内存卡插到电脑上复制。"
          },
          {
            "type": "olist",
            "items": [
              "手机安装 Canon Camera Connect。",
              "打开相机 Wi-Fi 或蓝牙，按屏幕提示连接手机。",
              "在 App 中选择照片或视频，保存到手机相册。",
              "电脑传输：取出内存卡，通过读卡器打开 DCIM 文件夹复制。",
              "镜头有灰尘时，先用气吹，再用镜头布轻轻擦拭。"
            ]
          },
          {
            "type": "p",
            "text": "[打开佳能官方 G7 X Mark III 完整说明书](https://pdisp01.c-wss.com/gdl/WWUFORedirectTarget.do?id=MDMwMDAzNzQ0MzA1&cmp=ASP&lang=ZH)"
          },
          {
            "type": "warn",
            "text": "不要把相机长时间放在高温、潮湿或阳光直射的地方。电池不建议长期放在完全没电的状态。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Canon Camera Connect](https://www.canon.com.cn/supports/download/app.html)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Canon Camera Connect，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：卡片相机 · 佳能无线蓝牙自拍杆版
  // 子目录内容：手持云台相机 · 大疆pocket3标准版
  "compact-vlog": {
    "desc": "佳能 G7 X Mark III 无线蓝牙自拍杆版简易教程",
    "keywords": "佳能 G7X3 蓝牙自拍杆 卡片相机 自拍 Vlog 录像 Wi-Fi",
    "steps": [
      {
        "title": "先认识这台相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "佳能 G7 X Mark III 是一台小巧的卡片相机，镜头不用拆装，开机就能拍，特别适合旅行和日常记录。"
          },
          {
            "type": "img",
            "src": "images/camera-compact-original.svg",
            "alt": "佳能 G7 X Mark III 官方使用说明书",
            "caption": "佳能官方 G7 X Mark III 使用说明书"
          },
          {
            "type": "list",
            "items": [
              "电源键：开机和关机。",
              "快门键：拍照；轻按对焦，按到底完成拍摄。",
              "红色短片键：开始和停止录像。",
              "变焦杆：拉近或拉远画面。",
              "回放键：查看拍好的照片和视频。"
            ]
          },
          {
            "type": "tip",
            "text": "新手先把模式转盘转到绿色 A+ 全自动，相机会自动调好亮度和颜色。"
          }
        ]
      },
      {
        "title": "安装电池和内存卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "相机底部是电池和内存卡仓。安装前先关机，按里面的方向标记放入即可。"
          },
          {
            "type": "olist",
            "items": [
              "打开底部仓盖。",
              "把官方电池按方向放进去，轻轻推到底。",
              "把 SD 内存卡按方向插入卡槽，听到轻微一声即可。",
              "盖好仓盖，确认卡扣锁紧。"
            ]
          },
          {
            "type": "warn",
            "text": "不要用力硬插电池或内存卡。相机提示卡速不足时，建议更换正规品牌的高速 SD 卡。"
          }
        ]
      },
      {
        "title": "开机和基础设置",
        "icon": "⚙️",
        "body": [
          {
            "type": "p",
            "text": "第一次开机后，按照屏幕提示选择语言、日期和时间。设置完成后就可以开始拍摄。"
          },
          {
            "type": "olist",
            "items": [
              "轻按快门键，相机就会自动对焦。",
              "用手指点屏幕，可以指定要对焦的位置。",
              "转动模式转盘选择拍照、自动或短片模式。",
              "向上翻开屏幕，可以自拍和低角度拍摄。",
              "不需要闪光灯时可以保持关闭，光线暗时再按闪光键打开。"
            ]
          },
          {
            "type": "tip",
            "text": "拍照前先确认屏幕上的电量和剩余可拍张数，避免拍到一半没电或内存不足。"
          }
        ]
      },
      {
        "title": "自拍杆和 Vlog 拍摄",
        "icon": "🤳",
        "body": [
          {
            "type": "p",
            "text": "把相机固定到蓝牙自拍杆上，再把屏幕翻转过来，就能看到自己并调整画面。"
          },
          {
            "type": "olist",
            "items": [
              "把相机牢固安装到自拍杆螺丝接口上。",
              "打开自拍杆蓝牙遥控器，按说明连接手机或相机支持的控制方式。",
              "翻转屏幕，确认人物和背景都出现在画面里。",
              "按快门拍照，或者按红色短片键拍摄 Vlog。",
              "拍摄时慢慢走动，不要快速甩动自拍杆。"
            ]
          },
          {
            "type": "tip",
            "text": "如果蓝牙遥控器无法拍照，可以直接使用相机快门键，或者在相机里打开自拍定时器。"
          }
        ]
      },
      {
        "title": "传照片和日常保养",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "照片可以传到手机，也可以把内存卡插到电脑上复制。"
          },
          {
            "type": "olist",
            "items": [
              "手机安装 Canon Camera Connect。",
              "打开相机 Wi-Fi 或蓝牙，按屏幕提示连接手机。",
              "在 App 中选择照片或视频，保存到手机相册。",
              "电脑传输：取出内存卡，通过读卡器打开 DCIM 文件夹复制。",
              "镜头有灰尘时，先用气吹，再用镜头布轻轻擦拭。"
            ]
          },
          {
            "type": "p",
            "text": "[打开佳能官方 G7 X Mark III 完整说明书](https://pdisp01.c-wss.com/gdl/WWUFORedirectTarget.do?id=MDMwMDAzNzQ0MzA1&cmp=ASP&lang=ZH)"
          },
          {
            "type": "warn",
            "text": "不要把相机长时间放在高温、潮湿或阳光直射的地方。电池不建议长期放在完全没电的状态。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[Canon Camera Connect](https://www.canon.com.cn/supports/download/app.html)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 Canon Camera Connect，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：CCD相机 · 佳能IXU210复古CCD相机
  "canon-ixus-210": {
    "desc": "佳能 IXUS 210 复古 CCD 简易使用教程",
    "keywords": "佳能 IXUS 210 CCD 相机 拍照 变焦 电池 存储卡",
    "steps": [
      {
        "title": "先认识 CCD 相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "这台相机操作简单，主要用开关、快门、变焦和回放键。复古 CCD 相机不需要复杂设置，先用自动模式就能拍。"
          },
          {
            "type": "img",
            "src": "images/canon-ixus-210-original.svg",
            "alt": "佳能复古 CCD 相机示意图",
            "caption": "原创 CCD 相机示意图"
          },
          {
            "type": "list",
            "items": [
              "电源键：开机和关机。",
              "快门键：轻按对焦，按到底拍照。",
              "变焦杆：拉近或拉远画面。",
              "回放键：查看已经拍好的照片。",
              "触摸屏：轻触屏幕可以选择对焦位置。"
            ]
          },
          {
            "type": "tip",
            "text": "复古 CCD 相机对光线比较敏感，白天和室内明亮环境下更容易拍出清楚的照片。"
          }
        ]
      },
      {
        "title": "安装电池和存储卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "先关机，再打开底部的电池仓盖。电池和存储卡按仓内的方向标记放入。"
          },
          {
            "type": "olist",
            "items": [
              "把电池对准方向放入电池仓。",
              "把存储卡按方向插到底。",
              "盖好仓盖并扣紧。",
              "开机后确认屏幕能显示电量。"
            ]
          },
          {
            "type": "warn",
            "text": "老相机建议使用状态正常的原规格电池。不要用力硬塞电池或存储卡。"
          }
        ]
      },
      {
        "title": "开机和基础设置",
        "icon": "⚙️",
        "body": [
          {
            "type": "p",
            "text": "第一次开机后，按照屏幕提示设置日期和时间，然后选择自动或普通拍摄模式。"
          },
          {
            "type": "olist",
            "items": [
              "按电源键开机。",
              "把模式转到 AUTO 自动拍摄。",
              "设置日期、时间和语言。",
              "用手指轻触屏幕选择对焦点。"
            ]
          },
          {
            "type": "tip",
            "text": "每次换电池后如果时间不对，重新设置日期和时间即可。"
          }
        ]
      },
      {
        "title": "拍照和查看照片",
        "icon": "📸",
        "body": [
          {
            "type": "olist",
            "items": [
              "眼睛看屏幕，把想拍的人和物放在画面中间。",
              "轻按快门对焦，按到底完成拍照。",
              "用变焦杆拉近或拉远画面。",
              "光线不足时可以打开闪光灯。",
              "按回放键查看照片，不满意可以直接删除重拍。"
            ]
          },
          {
            "type": "tip",
            "text": "拍摄时双手拿稳相机，按快门时先轻轻停一下，照片更不容易糊。"
          }
        ]
      },
      {
        "title": "导出照片和保养",
        "icon": "💾",
        "body": [
          {
            "type": "p",
            "text": "老款 CCD 相机通常使用存储卡或数据线传输。最稳定的方法是把存储卡取出，通过读卡器连接电脑。"
          },
          {
            "type": "olist",
            "items": [
              "关机后取出存储卡。",
              "把卡插入读卡器并连接电脑。",
              "打开 DCIM 文件夹，复制照片到电脑。",
              "传输完成后安全弹出读卡器。",
              "镜头用气吹和软布清理，不要用酒精直接擦拭。"
            ]
          },
          {
            "type": "p",
            "text": "[查看佳能 IXUS 210 官方使用者指南](https://www.canon.com.cn/supports/download/simsdetail/0300327102.html)"
          },
          {
            "type": "warn",
            "text": "不要经常插拔数据线来传照片，老相机接口容易松动。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "佳能 IXU210 和 IXU130 属于早期 CCD 卡片相机，通常没有 Wi-Fi 或蓝牙，也没有可连接手机导出的官方 App。请直接使用下面的 USB 有线连接或 USB 读卡器方法。"
          },
          {
            "type": "tip",
            "text": "不要安装来源不明的所谓手机连接 App，避免隐私和账号风险。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  // 子目录内容：CCD相机 · 佳能IXU130复古CCD相机
  "canon-ixus-130": {
    "desc": "佳能 IXUS 130 复古 CCD 简易使用教程",
    "keywords": "佳能 IXUS 130 CCD 相机 拍照 变焦 电池 存储卡",
    "steps": [
      {
        "title": "先认识 CCD 相机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "这台相机操作简单，主要用开关、快门、变焦和回放键。复古 CCD 相机不需要复杂设置，先用自动模式就能拍。"
          },
          {
            "type": "img",
            "src": "images/canon-ixus-130-original.svg",
            "alt": "佳能复古 CCD 相机示意图",
            "caption": "原创 CCD 相机示意图"
          },
          {
            "type": "list",
            "items": [
              "电源键：开机和关机。",
              "快门键：轻按对焦，按到底拍照。",
              "变焦杆：拉近或拉远画面。",
              "回放键：查看已经拍好的照片。"
            ]
          },
          {
            "type": "tip",
            "text": "复古 CCD 相机对光线比较敏感，白天和室内明亮环境下更容易拍出清楚的照片。"
          }
        ]
      },
      {
        "title": "安装电池和存储卡",
        "icon": "🔋",
        "body": [
          {
            "type": "p",
            "text": "先关机，再打开底部的电池仓盖。电池和存储卡按仓内的方向标记放入。"
          },
          {
            "type": "olist",
            "items": [
              "把电池对准方向放入电池仓。",
              "把存储卡按方向插到底。",
              "盖好仓盖并扣紧。",
              "开机后确认屏幕能显示电量。"
            ]
          },
          {
            "type": "warn",
            "text": "老相机建议使用状态正常的原规格电池。不要用力硬塞电池或存储卡。"
          }
        ]
      },
      {
        "title": "开机和基础设置",
        "icon": "⚙️",
        "body": [
          {
            "type": "p",
            "text": "第一次开机后，按照屏幕提示设置日期和时间，然后选择自动或普通拍摄模式。"
          },
          {
            "type": "olist",
            "items": [
              "按电源键开机。",
              "把模式转到 AUTO 自动拍摄。",
              "设置日期、时间和语言。",
              "使用方向键和功能键调整常用设置。"
            ]
          },
          {
            "type": "tip",
            "text": "每次换电池后如果时间不对，重新设置日期和时间即可。"
          }
        ]
      },
      {
        "title": "拍照和查看照片",
        "icon": "📸",
        "body": [
          {
            "type": "olist",
            "items": [
              "眼睛看屏幕，把想拍的人和物放在画面中间。",
              "轻按快门对焦，按到底完成拍照。",
              "用变焦杆拉近或拉远画面。",
              "光线不足时可以打开闪光灯。",
              "按回放键查看照片，不满意可以直接删除重拍。"
            ]
          },
          {
            "type": "tip",
            "text": "拍摄时双手拿稳相机，按快门时先轻轻停一下，照片更不容易糊。"
          }
        ]
      },
      {
        "title": "导出照片和保养",
        "icon": "💾",
        "body": [
          {
            "type": "p",
            "text": "老款 CCD 相机通常使用存储卡或数据线传输。最稳定的方法是把存储卡取出，通过读卡器连接电脑。"
          },
          {
            "type": "olist",
            "items": [
              "关机后取出存储卡。",
              "把卡插入读卡器并连接电脑。",
              "打开 DCIM 文件夹，复制照片到电脑。",
              "传输完成后安全弹出读卡器。",
              "镜头用气吹和软布清理，不要用酒精直接擦拭。"
            ]
          },
          {
            "type": "p",
            "text": "[查看佳能 IXUS 130 官方使用者指南](https://www.canon.com.cn/supports/download/simsdetail/0300366401.html)"
          },
          {
            "type": "warn",
            "text": "不要经常插拔数据线来传照片，老相机接口容易松动。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "佳能 IXU210 和 IXU130 属于早期 CCD 卡片相机，通常没有 Wi-Fi 或蓝牙，也没有可连接手机导出的官方 App。请直接使用下面的 USB 有线连接或 USB 读卡器方法。"
          },
          {
            "type": "tip",
            "text": "不要安装来源不明的所谓手机连接 App，避免隐私和账号风险。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      }
    ]
  },
  "tripod-live": {
    "desc": "富图宝 FY-830 + MH-4A 液压云台简易使用教程",
    "keywords": "富图宝 FY-830 MH-4A 三脚架 液压云台 直播 拍照 录像",
    "steps": [
      {
        "title": "先认识三脚架",
        "icon": "🔭",
        "body": [
          {
            "type": "p",
            "text": "FY-830 三脚架配 MH-4A 液压云台，主要用来把相机或手机稳稳架住，适合直播、拍视频、合影和长时间拍摄。"
          },
          {
            "type": "img",
            "src": "images/sanjiaojia.png",
            "alt": "三脚架结构示意图",
            "caption": "三脚架结构示意图"
          },
          {
            "type": "list",
            "items": [
              "三条脚管：支撑整个三脚架。",
              "脚管锁扣：负责拉长和锁紧脚管。",
              "中轴：用来升降高度。",
              "液压云台：控制左右转动和上下俯仰。",
              "快装板：先把相机或手机固定在这里，再装到云台上。",
              "水平泡：用来确认三脚架是否放平。"
            ]
          },
          {
            "type": "tip",
            "text": "不同批次的锁扣可能略有不同，以你拿到的实物为准。使用前先检查每一节脚管都已经锁紧。"
          }
        ]
      },
      {
        "title": "展开三脚架",
        "icon": "📐",
        "body": [
          {
            "type": "p",
            "text": "找一块平整的地面，先把三条腿分开，再逐节拉长。不要在地面不平、风很大或容易被人碰到的地方只拉一半腿。"
          },
          {
            "type": "olist",
            "items": [
              "把三条腿均匀向外打开。",
              "打开脚管锁扣，把脚管一节一节拉出。",
              "每拉出一节，马上把锁扣压紧或旋紧。",
              "轻轻按一下三脚架，确认三条腿不会继续缩回。",
              "调整高度后，看云台上的水平泡，让气泡尽量待在圆圈中间。"
            ]
          },
          {
            "type": "warn",
            "text": "不要在相机已经装到云台上时猛拉脚管。先把架子调好，再安装相机或手机。"
          }
        ]
      },
      {
        "title": "安装相机或手机",
        "icon": "📷",
        "body": [
          {
            "type": "p",
            "text": "先把快装板装到相机或手机支架上，再把快装板装到云台。安装时一只手扶住云台，另一只手操作。"
          },
          {
            "type": "olist",
            "items": [
              "把快装板螺丝拧到相机底部，拧紧但不要用过猛力气。",
              "手机使用时，把手机夹固定好，再装到快装板上。",
              "把快装板对准云台卡槽，推到位后锁紧。",
              "轻轻摇一下设备，确认不会松动。",
              "调整设备重心，让相机或手机尽量保持在云台正上方。"
            ]
          },
          {
            "type": "warn",
            "text": "快装板没有锁紧前不要松手。相机镜头较长或设备较重时，要双手扶稳后再调节角度。"
          }
        ]
      },
      {
        "title": "调节液压云台",
        "icon": "🎬",
        "body": [
          {
            "type": "p",
            "text": "MH-4A 液压云台可以左右转动和上下抬头低头。想固定画面时，把对应的锁钮拧紧即可。"
          },
          {
            "type": "olist",
            "items": [
              "先松开左右转动锁，调整画面方向，再锁紧。",
              "松开俯仰锁，调整上下角度，再锁紧。",
              "使用手柄慢慢转动云台，画面会更平稳。",
              "拍视频时不要突然推拉，慢慢转动更自然。",
              "拍竖屏直播或自拍时，确认手机夹和整体重心稳定后再松手。"
            ]
          },
          {
            "type": "tip",
            "text": "不用云台时要及时把锁钮锁好，防止设备突然低头或倾倒。"
          }
        ]
      },
      {
        "title": "收纳和保养",
        "icon": "🧰",
        "body": [
          {
            "type": "p",
            "text": "拍完以后先把相机或手机取下来，再收三脚架。这样比连设备一起收更安全。"
          },
          {
            "type": "olist",
            "items": [
              "锁住云台，取下相机或手机。",
              "松开脚管锁扣，从最细的一节开始收回。",
              "把三条腿并拢，锁好脚管再放回收纳袋。",
              "海边或沙地使用后，用干布擦掉沙子和水汽。",
              "长期不用时放在干燥处，不要压在重物下面。"
            ]
          },
          {
            "type": "p",
            "text": "[查看 Fotopro 官方网站](https://www.fotopro.com/)"
          },
          {
            "type": "warn",
            "text": "不要往锁扣里乱加润滑油。沙尘进入锁扣时，先用干布清理，再检查锁紧是否正常。"
          }
        ]
      }
    ]
  },
  // 子目录内容：落地三脚架 · 富宝图FY-830-MH-4A所含配件可自选赠送使用
  "tripod-cam": {
    "desc": "富图宝 FY-830 + MH-4A 配件自选使用简易教程",
    "keywords": "富图宝 FY-830 MH-4A 三脚架 配件 手机夹 独脚架 自拍杆",
    "steps": [
      {
        "title": "可选三脚架配件（提前联系客服进行咨询需要的配件）",
        "icon": "🧩",
        "body": [
          {
            "type": "p",
            "text": "此页面只为显示可赠送的配件，详细使用说明可参考上一页"
          },
          {
            "type": "olist",
            "items": [
              "富宝图FY-830-MH-4A 手机增位夹",
              "富宝图FY-830-MH-4A 小桌板。",
              "富宝图FY-830-MH-4A 手持云台相机支架。",
              "富宝图FY-830-MH-4A vivo脚架环。",
              "富宝图FY-830-MH-4A 转接器。",
              "富宝图FY-830-MH-4A 30CM延长杆",
              "如有其他配件可详细咨询首页客服~"
            ]
          },
          {
            "type": "warn",
            "text": "小配件大部分可免费赠送使用，具体以库存为准，请提前联系客服确认。"
          }
        ]
      },
    ],
  },

  /* ---------- 内存卡数据丢失找回 SD内存卡 ----------
*/

  // 子目录内容：内存卡数据找回 · SD 卡
  "recovery-sd": {
    "desc": "拍摄照片或视频误删尝试找回（不是百分百概率找回）",
    "keywords": "内存卡 数据恢复 照片 视频 SD卡 TF卡 误删 格式化",
    "steps": [
      {
        "title": "闪迪SD内存卡官方数据找回修复软件",
        "icon": "🧰",
        "body": [
          {
            "type": "p",
            "text": "如误删或格式化了内存卡，请立即停止拍摄，也不要再向卡内写入新数据，以免覆盖后无法找回。"
          },
          {
            "type": "olist",
            "items": [
              "注意：此操作仅限电脑端。如不熟悉操作，请联系客服或前往本地数据恢复门店。",
              "关闭相机后取出内存卡，插入读卡器并连接电脑，再安装对应品牌的官方恢复软件。",
              "Windows 下载地址：[SanDisk RescuePRO Deluxe Windows 版](https://www.lc-tech.com/productdemo/RP/RPDLXWIN.zip)",
              "Mac 下载地址：[SanDisk RescuePRO Deluxe Mac 版](https://www.lc-tech.com/productdemo/RP/RPDLXMAC.zip)",
              "注意：非专业人员请勿自行操作；操作可能导致数据丢失，相关风险需自行承担。"
            ]
          },
          {
            "type": "warn",
            "text": "操作存在风险；如内存卡出现异常、数据丢失或损坏，相关责任需自行承担。"
          }
        ]
      },
 {
        "title": "雷克沙SD内存卡官方数据找回修复软件",
        "icon": "🧰",
        "body": [
          {
            "type": "p",
            "text": "如误删或格式化了内存卡，请立即停止拍摄，也不要再向卡内写入新数据，以免覆盖后无法找回。"
          },
          {
            "type": "olist",
            "items": [
              "注意：此操作仅限电脑端。如不熟悉操作，请联系客服或前往本地数据恢复门店。",
              "关闭相机后取出内存卡，插入读卡器并连接电脑，再安装对应品牌的官方恢复软件。",
              "Windows 下载地址：[Lexar 数据恢复 Windows 版](https://www-oss.lexar.com/lexar/resource/files/2025-08-28/Lexar%20%E6%95%B0%E6%8D%AE%E6%81%A2%E5%A4%8D%20Windows%E7%89%88%E6%9C%AC.zip)",
              "Mac 下载地址：[Lexar 数据恢复 Mac 版](https://www-oss.lexar.com/lexar/resource/files/2024-12-31/Lexar%20%E6%95%B0%E6%8D%AE%E6%81%A2%E5%A4%8D%20Mac%E7%89%88%E6%9C%AC.zip)",
              "注意：非专业人员请勿自行操作；操作可能导致数据丢失，相关风险需自行承担。"
            ]
          },
          {
            "type": "warn",
            "text": "操作存在风险；如内存卡出现异常、数据丢失或损坏，相关责任需自行承担。"
          }
        ]
      },
    ]
  },


    /* ---------- 内存卡数据丢失找回 TF内存卡 ----------
*/
  // 子目录内容：内存卡数据找回 · TF 卡
  "recovery-tf": {
    "desc": "拍摄照片或视频误删尝试找回（不是百分百概率找回）",
    "keywords": "内存卡 数据恢复 照片 视频 SD卡 TF卡 误删 格式化",
    "steps": [
      {
        "title": "闪迪TF内存卡官方数据找回修复软件",
        "icon": "🧰",
        "body": [
          {
            "type": "p",
            "text": "如误删或格式化了内存卡，请立即停止拍摄，也不要再向卡内写入新数据，以免覆盖后无法找回。"
          },
          {
            "type": "olist",
            "items": [
              "注意：此操作仅限电脑端。如不熟悉操作，请联系客服或前往本地数据恢复门店。",
              "关闭相机后取出内存卡，插入读卡器并连接电脑，再安装对应品牌的官方恢复软件。",
              "Windows 下载地址：[SanDisk RescuePRO Deluxe Windows 版](https://www.lc-tech.com/productdemo/RP/RPDLXWIN.zip)",
              "Mac 下载地址：[SanDisk RescuePRO Deluxe Mac 版](https://www.lc-tech.com/productdemo/RP/RPDLXMAC.zip)",
              "注意：非专业人员请勿自行操作；操作可能导致数据丢失，相关风险需自行承担。"
            ]
          },
          {
            "type": "warn",
            "text": "操作存在风险；如内存卡出现异常、数据丢失或损坏，相关责任需自行承担。"
          }
        ]
      },
 {
        "title": "雷克沙TF内存卡官方数据找回修复软件",
        "icon": "🧰",
        "body": [
          {
            "type": "p",
            "text": "如误删或格式化了内存卡，请立即停止拍摄，也不要再向卡内写入新数据，以免覆盖后无法找回。"
          },
          {
            "type": "olist",
            "items": [
              "注意：此操作仅限电脑端。如不熟悉操作，请联系客服或前往本地数据恢复门店。",
              "关闭相机后取出内存卡，插入读卡器并连接电脑，再安装对应品牌的官方恢复软件。",
              "Windows 下载地址：[Lexar 数据恢复 Windows 版](https://www-oss.lexar.com/lexar/resource/files/2025-08-28/Lexar%20%E6%95%B0%E6%8D%AE%E6%81%A2%E5%A4%8D%20Windows%E7%89%88%E6%9C%AC.zip)",
              "Mac 下载地址：[Lexar 数据恢复 Mac 版](https://www-oss.lexar.com/lexar/resource/files/2024-12-31/Lexar%20%E6%95%B0%E6%8D%AE%E6%81%A2%E5%A4%8D%20Mac%E7%89%88%E6%9C%AC.zip)",
              "注意：非专业人员请勿自行操作；操作可能导致数据丢失，相关风险需自行承担。"
            ]
          },
          {
            "type": "warn",
            "text": "操作存在风险；如内存卡出现异常、数据丢失或损坏，相关责任需自行承担。"
          }
        ]
      },
      
    ]
  },

  // 子目录内容：手持云台相机 · 大疆Pocket 4 Pro标准套装
  "gimbal-pocket4pro-standard": {
    "desc": "大疆 Osmo Pocket 4P 标准套装简易使用教程",
    "keywords": "大疆 Osmo Pocket 4P Pocket 4 Pro 标准套装 手持云台 相机 开机 拍照 录像 DJI Mimo 导出",
    "steps": [
      {
        "title": "开箱与套装确认",
        "icon": "📦",
        "body": [
          {
            "type": "p",
            "text": "本教程适用于大疆 Osmo Pocket 4P（网站显示名称为“大疆 Pocket 4 Pro 标准套装”）。Pocket 4P 的屏幕、云台和手柄结构与其他 Pocket 系列类似，具体菜单名称以实际设备为准。"
          },
          {
            "type": "p",
            "text": "官方页面：[DJI Osmo Pocket 4P 官方页面](https://www.dji.com/cn/osmo-pocket-4p)；官方下载与说明书：[DJI Osmo Pocket 4P 官方下载](https://www.dji.com/cn/osmo-pocket-4p/downloads)。"
          },
          {
            "type": "img",
            "src": "images/category-icons/children/pocket4pro-standard.svg",
            "alt": "大疆 Pocket 4 Pro 标准套装图标示意",
            "caption": "标准套装结构与主要配件示意图"
          },
          {
            "type": "list",
            "items": [
              "相机主机 x1",
              "保护壳或收纳配件 x1",
              "USB-C 数据线 x1（按实际配置）",
              "内存卡或读卡器（按租赁配置）",
              "快速入门说明资料"
            ]
          },
          {
            "type": "tip",
            "text": "不同批次和租赁组合的配件可能略有不同，请以实际随箱清单为准；如发现少件或外观异常，请先联系客服。"
          }
        ]
      },
      {
        "title": "首次开机和激活",
        "icon": "🔌",
        "body": [
          {
            "type": "p",
            "text": "首次使用前先充电。轻推屏幕向左旋转，屏幕点亮后云台会自动展开；不要用力按压屏幕或掰动云台转轴。"
          },
          {
            "type": "olist",
            "items": [
              "使用官方 USB-C 数据线给相机充电。",
              "轻推屏幕向左旋转，等待屏幕和云台启动。",
              "按屏幕提示完成语言、日期等基础设置。",
              "如需激活或更新，打开 DJI Mimo 并按提示连接相机。",
              "云台自检完成、画面稳定后再开始拍摄。"
            ]
          },
          {
            "type": "tip",
            "text": "如果长时间未开机，先充电 20-30 分钟再试。出现持续异响、发热或云台卡住时，请停止操作并联系客服。"
          }
        ]
      },
      {
        "title": "认识屏幕、摇杆和按键",
        "icon": "🎛️",
        "body": [
          {
            "type": "p",
            "text": "相机主要操作都在触摸屏和机身按键上完成。"
          },
          {
            "type": "list",
            "items": [
              "触摸屏：点击屏幕选择对焦位置、切换模式或修改参数。",
              "摇杆：向上/下/左/右拨动，控制画面方向和变焦。",
              "录制键：开始和结束录像。",
              "电源/模式键：短按或长按的功能以实际设备提示为准。"
            ]
          },
          {
            "type": "tip",
            "text": "拍摄时不要用手强行转动云台，尽量通过摇杆控制方向，避免损伤云台电机。"
          }
        ]
      },
      {
        "title": "拍照和录像",
        "icon": "🎬",
        "body": [
          {
            "type": "p",
            "text": "横屏适合拍风景和 Vlog，竖屏适合拍人像、短视频和直播。"
          },
          {
            "type": "olist",
            "items": [
              "打开相机，进入拍照或录像模式。",
              "点击屏幕选择对焦位置。",
              "按录制键开始拍摄，再次按下结束。",
              "在相册中回看素材，不满意的可以删除重拍。"
            ]
          },
          {
            "type": "warn",
            "text": "云台开始运动前，确认镜头前没有手指、挂绳或其他遮挡物。"
          }
        ]
      },
      {
        "title": "连接 DJI Mimo 和固件更新",
        "icon": "📱",
        "body": [
          {
            "type": "p",
            "text": "官方 App 下载：[DJI Mimo](https://www.dji.com/cn/downloads/djiapp/dji-mimo)。请在手机应用商店搜索同名 App，并选择官方发布者。"
          },
          {
            "type": "olist",
            "items": [
              "打开相机电源和手机蓝牙、Wi-Fi。",
              "打开 DJI Mimo，选择添加设备或连接相机。",
              "按屏幕提示完成配对。",
              "进入设备页面查看固件版本；有新版本时按提示更新。",
              "更新过程中不要关机、断网或退出 App。"
            ]
          },
          {
            "type": "tip",
            "text": "如果搜不到相机，先关闭并重新打开蓝牙、Wi-Fi，再重启相机和 App 后重试。"
          }
        ]
      },
      {
        "title": "收纳和保养",
        "icon": "🎒",
        "body": [
          {
            "type": "olist",
            "items": [
              "关机后等待云台回到收纳位置。",
              "安装保护壳或收纳配件，避免挤压镜头和云台。",
              "收纳前确认机身和镜头没有沙粒、水汽。",
              "长期不用时放在干燥阴凉处，并定期补电。"
            ]
          },
          {
            "type": "warn",
            "text": "不要强行掰动云台转轴，也不要让镜头长时间正对强光。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[DJI Mimo](https://www.dji.com/cn/downloads/djiapp/dji-mimo)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 DJI Mimo，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      },
      {
        "title": "常见问题排查",
        "icon": "🛠️",
        "body": [
          {
            "type": "p",
            "text": "遇到问题时，可以按下面的顺序检查："
          },
          {
            "type": "olist",
            "items": [
              "确认电量是否充足，先充电再开机。",
              "确认屏幕已旋转到位，云台没有被卡住。",
              "重启相机和手机 App 后重新连接。",
              "检查内存卡是否插好、剩余空间是否足够。",
              "仍无法解决时，请联系客服并提供设备型号和问题照片或视频。"
            ]
          }
        ]
      }
    ]
  },
  // 子目录内容：手持云台相机 · 大疆Pocket 4 Pro全能套装
  "gimbal-pocket4pro-combo": {
    "desc": "大疆 Osmo Pocket 4P 全能套装简易使用教程",
    "keywords": "大疆 Osmo Pocket 4P Pocket 4 Pro 全能套装 续航手柄 三脚架 麦克风 手持云台 相机 导出",
    "steps": [
      {
        "title": "开箱与套装配件确认",
        "icon": "📦",
        "body": [
          {
            "type": "p",
            "text": "本教程按常见的“全能套装”配件组合编写，适用于大疆 Osmo Pocket 4P（网站显示名称为“大疆 Pocket 4 Pro 全能套装”）。官方公开页面目前展示标准套装，全能套装的配件以实际随箱清单和租赁页面为准。"
          },
          {
            "type": "p",
            "text": "官方页面：[DJI Osmo Pocket 4P 官方页面](https://www.dji.com/cn/osmo-pocket-4p)；官方下载与说明书：[DJI Osmo Pocket 4P 官方下载](https://www.dji.com/cn/osmo-pocket-4p/downloads)。"
          },
          {
            "type": "img",
            "src": "images/category-icons/children/pocket4pro-combo.svg",
            "alt": "大疆 Pocket 4 Pro 全能套装示意",
            "caption": "全能套装配件组合示意图（以实际清单为准）"
          },
          {
            "type": "list",
            "items": [
              "相机主机和标准配件",
              "续航手柄或底部延长配件",
              "迷你三脚架或支撑配件",
              "无线麦克风发射器（如随箱配置）",
              "增广镜、防风毛套或其他创作配件（如随箱配置）"
            ]
          },
          {
            "type": "warn",
            "text": "不同批次、不同租赁套餐的配件会不同，请勿按本清单直接判断少件，以订单和随箱清单为准。"
          }
        ]
      },
      {
        "title": "安装底部手柄或续航配件",
        "icon": "🔧",
        "body": [
          {
            "type": "p",
            "text": "先把相机完全关机，再安装底部配件；安装前确认接口方向，不要硬插。"
          },
          {
            "type": "olist",
            "items": [
              "关机后擦干净相机底部和配件接口。",
              "对准卡扣或螺纹方向，轻轻推入或旋紧。",
              "确认连接牢固后再开机。",
              "使用结束后先关机，再拆下配件。"
            ]
          },
          {
            "type": "warn",
            "text": "不要在云台通电时强行旋转或拉扯相机。"
          }
        ]
      },
      {
        "title": "安装迷你三脚架或支撑配件",
        "icon": "📐",
        "body": [
          {
            "type": "olist",
            "items": [
              "展开三脚架并放在平整、稳固的桌面或地面。",
              "把相机或手柄固定到三脚架上。",
              "调整拍摄角度，确认重心稳定后再松手。",
              "不用时先取下相机，再收三脚架。"
            ]
          },
          {
            "type": "tip",
            "text": "户外使用时注意防风；风大时不要只依赖小型三脚架。"
          }
        ]
      },
      {
        "title": "连接无线麦克风",
        "icon": "🎙️",
        "body": [
          {
            "type": "p",
            "text": "如套装包含无线麦克风，请先给发射器充电，再按官方说明连接相机。不同麦克风型号的连接方式可能不同。"
          },
          {
            "type": "olist",
            "items": [
              "打开麦克风发射器和相机的电源。",
              "按官方说明完成接收器和相机的连接。",
              "在相机中确认收音设备已经被识别。",
              "拍摄前试录一段，回放检查声音是否正常。"
            ]
          },
          {
            "type": "tip",
            "text": "不要把麦克风放在相机扬声器正上方，避免产生啸叫或回声。"
          }
        ]
      },
      {
        "title": "常用拍摄组合",
        "icon": "🎬",
        "body": [
          {
            "type": "p",
            "text": "全能套装适合 Vlog、旅拍、自拍和简单采访，可以根据场景选择手柄、三脚架和麦克风组合。"
          },
          {
            "type": "list",
            "items": [
              "手持 Vlog：相机 + 底部手柄。",
              "固定拍摄：相机 + 迷你三脚架。",
              "人物采访：相机 + 无线麦克风。",
              "户外移动：收紧配件，避免松动和掉落。"
            ]
          },
          {
            "type": "tip",
            "text": "不要同时安装过多配件；配件越多，越要检查接口和重心是否牢固。"
          }
        ]
      },
      {
        "title": "收纳和保养",
        "icon": "🎒",
        "body": [
          {
            "type": "olist",
            "items": [
              "关机后先拆下可拆卸配件。",
              "云台回到收纳位置后安装保护壳。",
              "把麦克风、三脚架、手柄分别放入收纳包。",
              "擦干水汽和沙尘，再合上收纳包。",
              "长期不用时放在干燥处并定期补电。"
            ]
          },
          {
            "type": "warn",
            "text": "不要把配件硬塞进收纳包，以免挤压镜头、屏幕或云台。"
          }
        ]
      },
      {
        "title": "如何导出照片和视频",
        "icon": "📤",
        "body": [
          {
            "type": "p",
            "text": "导出照片和视频有三种常用方法。可以先试官方 App，也可以用 USB 数据线连接手机，或者用 USB 读卡器连接手机。"
          },
          {
            "type": "p",
            "text": "**方法一：下载官方 App，无线连接相机导出**"
          },
          {
            "type": "p",
            "text": "官方 App 下载入口：[DJI Mimo](https://www.dji.com/cn/downloads/djiapp/dji-mimo)。请在手机应用商店搜索同名 App，优先选择官方发布者。"
          },
          {
            "type": "img",
            "src": "images/export-app-wireless-original.svg",
            "alt": "官方 App 无线连接相机导出素材示意图",
            "caption": "官方 App 无线连接和导出步骤"
          },
          {
            "type": "olist",
            "items": [
              "在手机应用商店下载并安装 DJI Mimo，注册或登录需要的账号。",
              "打开相机电源，进入相机设置，开启 Wi-Fi、蓝牙或无线功能。不同相机的入口名称可能是无线连接、手机连接或传输。",
              "手机打开蓝牙和 Wi-Fi，启动官方 App，选择添加设备或连接相机。",
              "相机屏幕出现配对提示时，点击允许、确认或配对。部分相机需要输入相机屏幕上显示的验证码。",
              "连接成功后，在 App 中进入相册、相机上的图像或下载页面。",
              "选择要保存的照片或视频。视频建议选择原始画质或下载到 App，再点击导出或下载到手机。",
              "等待进度完成，不要关闭相机、退出 App 或锁屏。完成后到手机系统相册检查文件。"
            ]
          },
          {
            "type": "tip",
            "text": "如果找不到相册，请查看手机的“相册”“图库”“文件”或“最近项目”。部分视频需要先在 App 中下载完成，再导出到系统相册。"
          },
          {
            "type": "p",
            "text": "**方法二：使用 USB 数据线连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-cable-phone-original.svg",
            "alt": "USB 数据线连接手机导出照片视频示意图",
            "caption": "USB 数据线连接手机和文件保存步骤"
          },
          {
            "type": "olist",
            "items": [
              "确认手机接口。安卓手机通常需要 USB-C 或 OTG 转接头；iPhone 需要匹配 Lightning 或 USB-C 的相机转接方案。",
              "使用相机支持的官方 USB 数据线，把相机连接到手机。只有充电线时可能只能充电，不能传文件，需要换成数据线。",
              "打开相机电源。相机屏幕如果出现 USB 模式，请选择文件传输、U盘模式、PTP 或相机连接。",
              "手机下拉通知栏，把 USB 用途改成文件传输、传输文件或查看文件。",
              "打开手机自带的文件管理 App，找到 USB 存储、相机、外部设备或 Canon Digital Camera。",
              "进入 DCIM 文件夹，再打开 Camera01 或类似文件夹。这里就是相机拍摄的照片和视频。",
              "长按选择需要的文件，点击复制或移动。保存到手机相册、Pictures、Downloads 或你容易找到的文件夹。",
              "复制完成后，在手机相册中刷新或重新扫描媒体文件，再安全断开数据线。"
            ]
          },
          {
            "type": "warn",
            "text": "传输过程中不要强行拔线。如果手机找不到相机，先更换支持数据传输的线材，或者直接使用读卡器。"
          },
          {
            "type": "p",
            "text": "**方法三：使用 USB 读卡器连接手机保存**"
          },
          {
            "type": "img",
            "src": "images/export-reader-phone-original.svg",
            "alt": "USB 读卡器连接手机导出照片视频示意图",
            "caption": "取出存储卡、连接读卡器和保存素材步骤"
          },
          {
            "type": "olist",
            "items": [
              "先关闭相机，等待相机完全断电。不要热插拔存储卡。",
              "打开相机的存储卡槽盖，轻轻按一下存储卡，卡会弹出，再把它取出。",
              "按照缺口方向把存储卡插入 USB 读卡器。插不进去时不要硬按，换一个方向再试。",
              "把 USB 读卡器连接到手机。安卓手机可能需要 OTG 转接头；iPhone 需要匹配接口的读卡器或转接器。",
              "手机识别读卡器后，打开文件管理 App，找到 USB 存储、外部存储或读卡器名称。",
              "进入 DCIM 文件夹，找到相机拍摄的图片和视频。佳能相机通常还会在 DCIM 下创建 100CANON 等文件夹。",
              "长按选择素材，点击复制或移动到手机相册目录。建议保留原文件，确认保存成功后再格式化存储卡。",
              "复制完成后安全弹出读卡器，再拔下读卡器并把存储卡装回相机。"
            ]
          },
          {
            "type": "tip",
            "text": "如果复制后在文件管理里能看到、但相册没有显示，请重启相册 App，或在文件管理里选择“移动到相册/图片”后再刷新。"
          },
          {
            "type": "warn",
            "text": "不要把存储卡直接格式化，也不要删除原素材，直到确认手机和电脑中都已经成功保存。"
          }
        ]
      },
      {
        "title": "常见问题排查",
        "icon": "🛠️",
        "body": [
          {
            "type": "olist",
            "items": [
              "配件不识别：关机后重新安装，确认接口方向正确。",
              "麦克风无声：检查电量、连接状态和相机收音设置。",
              "画面不稳：检查三脚架是否锁紧、重心是否偏移。",
              "无法连接 App：重启相机、手机蓝牙和 Wi-Fi 后重试。",
              "仍无法解决时，请联系客服并提供配件照片和问题描述。"
            ]
          }
        ]
      }
    ]
  }

}


